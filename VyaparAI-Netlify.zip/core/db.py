import sqlite3
import re
import json
import uuid
import datetime
from decimal import Decimal
import pymysql
import pymysql.cursors
from config import Config

class DatabaseManager:
    """
    Unified database manager for VyaparAI supporting both MySQL 8.0+ and SQLite.
    Automatically handles parameter translation (%s to ? for SQLite) and decimal conversions.
    """
    def __init__(self):
        self.db_type = Config.DB_TYPE
        self.is_fallback = False
        self.fallback_reason = None

    def get_connection(self):
        if self.db_type == 'mysql':
            try:
                conn = pymysql.connect(
                    host=Config.DB_HOST,
                    port=Config.DB_PORT,
                    user=Config.DB_USER,
                    password=Config.DB_PASSWORD,
                    database=Config.DB_NAME,
                    cursorclass=pymysql.cursors.DictCursor,
                    autocommit=True,
                    charset='utf8mb4'
                )
                return conn, 'mysql'
            except Exception as e:
                self.is_fallback = True
                self.fallback_reason = f"MySQL connection failed ({e}). Falling back to local SQLite engine."
                # Fall back to SQLite gracefully
                return self._get_sqlite_connection(), 'sqlite'
        else:
            return self._get_sqlite_connection(), 'sqlite'

    def _get_sqlite_connection(self):
        conn = sqlite3.connect(str(Config.SQLITE_PATH), timeout=20.0)
        conn.row_factory = sqlite3.Row
        # Enable foreign key support in SQLite
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _translate_sql(self, sql, engine):
        """Translates MySQL syntax to SQLite if running in SQLite mode."""
        if engine == 'sqlite':
            # Translate %s parameter placeholders to ?
            # (Ensuring not to replace literal % if any)
            translated = re.sub(r'(?<!%)%s', '?', sql)
            # Remove ON UPDATE CURRENT_TIMESTAMP
            translated = re.sub(r'ON UPDATE CURRENT_TIMESTAMP', '', translated, flags=re.IGNORECASE)
            # Replace LONGTEXT with TEXT
            translated = re.sub(r'LONGTEXT', 'TEXT', translated, flags=re.IGNORECASE)
            return translated
        return sql

    def execute_query(self, sql, params=None):
        """Executes a SELECT query and returns rows as list of dicts."""
        conn, engine = self.get_connection()
        try:
            sql_exec = self._translate_sql(sql, engine)
            cur = conn.cursor()
            cur.execute(sql_exec, params or ())
            rows = cur.fetchall()
            
            # Format rows as list of standard dicts with serialized decimals
            results = []
            for row in rows:
                if isinstance(row, sqlite3.Row):
                    d = dict(row)
                elif isinstance(row, dict):
                    d = dict(row)
                else:
                    d = dict(zip([col[0] for col in cur.description], row))
                
                # Format Decimals and Dates for JSON safety
                for k, v in d.items():
                    if isinstance(v, Decimal):
                        d[k] = float(v)
                    elif isinstance(v, (datetime.date, datetime.datetime)):
                        d[k] = v.isoformat()
                results.append(d)
            return results
        finally:
            conn.close()

    def execute_one(self, sql, params=None):
        """Executes a SELECT query and returns the first row or None."""
        rows = self.execute_query(sql, params)
        return rows[0] if rows else None

    def execute_commit(self, sql, params=None):
        """Executes INSERT, UPDATE, DELETE query and commits."""
        conn, engine = self.get_connection()
        try:
            sql_exec = self._translate_sql(sql, engine)
            cur = conn.cursor()
            cur.execute(sql_exec, params or ())
            if engine == 'sqlite':
                conn.commit()
            last_id = cur.lastrowid
            affected = cur.rowcount
            return {'last_id': last_id, 'affected': affected}
        finally:
            conn.close()

    def init_database(self):
        """Initializes tables using schema.sql and seeds default business if empty."""
        conn, engine = self.get_connection()
        try:
            schema_file = Config.BASE_DIR / "schema.sql"
            with open(schema_file, "r", encoding="utf-8") as f:
                schema_content = f.read()

            if engine == 'mysql':
                cur = conn.cursor()
                for statement in schema_content.split(';'):
                    stmt = statement.strip()
                    if stmt:
                        cur.execute(stmt)
            else:
                # SQLite schema translation
                sqlite_schema = schema_content
                sqlite_schema = re.sub(r'LONGTEXT', 'TEXT', sqlite_schema, flags=re.IGNORECASE)
                sqlite_schema = re.sub(r'ON UPDATE CURRENT_TIMESTAMP', '', sqlite_schema, flags=re.IGNORECASE)
                sqlite_schema = re.sub(r'AUTO_INCREMENT', 'AUTOINCREMENT', sqlite_schema, flags=re.IGNORECASE)
                # Remove MySQL specific index statements inside CREATE TABLE if necessary
                statements = [s.strip() for s in sqlite_schema.split(';') if s.strip()]
                cur = conn.cursor()
                for s in statements:
                    try:
                        cur.execute(s)
                    except Exception as e:
                        # Continue if harmless index creation syntax warning in SQLite
                        pass
                conn.commit()

            # Ensure default business exists
            self._ensure_default_business()
            return True, f"Database initialized successfully with {engine.upper()} engine."
        except Exception as e:
            return False, f"Database initialization error: {str(e)}"
        finally:
            conn.close()

    def _ensure_default_business(self):
        """Creates demo MSME profile and live MSME profile if they don't exist."""
        # 1. Demo Business
        demo_biz = self.execute_one("SELECT * FROM businesses WHERE id = %s", ("biz_default_kanpur",))
        if not demo_biz:
            sql = """
            INSERT INTO businesses (id, name, business_type, city, state, currency, gstin, payment_terms, priorities)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            self.execute_commit(sql, (
                "biz_default_kanpur",
                "Sharma Electricals & Hardware Enterprises",
                "Wholesale & Retail Trading",
                "Kanpur",
                "Uttar Pradesh",
                "INR",
                "09AAACH7409R1ZZ",
                "Net 30",
                "Maintain steady cash flow, expedite overdue collection from large contractors, optimize working capital."
            ))

        # 2. Live Business
        live_biz = self.execute_one("SELECT * FROM businesses WHERE id = %s", ("biz_live_enterprise",))
        if not live_biz:
            sql = """
            INSERT INTO businesses (id, name, business_type, city, state, currency, gstin, payment_terms, priorities)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            self.execute_commit(sql, (
                "biz_live_enterprise",
                "My Real MSME Business",
                "Trading & Manufacturing",
                "Kanpur",
                "Uttar Pradesh",
                "INR",
                "",
                "Net 30",
                "Track genuine invoices, manage cash flow, and collect receivables on time."
            ))

    def get_current_mode(self):
        """Returns 'demo' or 'live' from system state (defaults to 'demo')."""
        setting = self.execute_one("SELECT config_json FROM integrations WHERE id = 'app_mode_setting'")
        if setting and setting.get("config_json"):
            try:
                data = json.loads(setting["config_json"])
                return data.get("mode", "demo")
            except Exception:
                pass
        return "demo"

    def set_current_mode(self, mode):
        """Sets 'demo' or 'live' mode in database."""
        mode_val = "live" if mode.lower() == "live" else "demo"
        payload = json.dumps({"mode": mode_val})
        check = self.execute_one("SELECT id FROM integrations WHERE id = 'app_mode_setting'")
        if check:
            self.execute_commit("UPDATE integrations SET config_json = %s WHERE id = 'app_mode_setting'", (payload,))
        else:
            self.execute_commit("""
            INSERT INTO integrations (id, business_id, service_name, is_enabled, config_json)
            VALUES ('app_mode_setting', 'biz_default_kanpur', 'mode_switcher', 1, %s)
            """, (payload,))
        return mode_val

    def get_active_business(self):
        """Returns the active business profile based on current mode ('demo' or 'live')."""
        self._ensure_default_business()
        mode = self.get_current_mode()
        target_id = "biz_live_enterprise" if mode == "live" else "biz_default_kanpur"
        biz = self.execute_one("SELECT * FROM businesses WHERE id = %s", (target_id,))
        if not biz:
            biz = self.execute_one("SELECT * FROM businesses ORDER BY created_at ASC LIMIT 1")
        return biz

    def get_status_info(self):
        """Returns connection status, engine name, fallback info, and active mode."""
        conn, engine = self.get_connection()
        conn.close()
        return {
            "engine": engine,
            "configured_type": self.db_type,
            "is_fallback": self.is_fallback,
            "fallback_reason": self.fallback_reason,
            "database_name": Config.DB_NAME if engine == 'mysql' else "vyaparai.db",
            "active_mode": self.get_current_mode()
        }

# Global singleton
db = DatabaseManager()
