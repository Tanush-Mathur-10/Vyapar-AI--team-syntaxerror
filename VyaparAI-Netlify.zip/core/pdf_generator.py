import os
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from config import Config

def amount_to_indian_words(amount):
    """Converts a monetary amount into formal Indian English words."""
    try:
        amt = int(round(float(amount)))
        if amt <= 0:
            return "Rupees Zero Only"
        ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
                "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
                "Seventeen", "Eighteen", "Nineteen"]
        tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
        
        def helper(n):
            if n < 20:
                return ones[n]
            elif n < 100:
                return tens[n // 10] + (" " + ones[n % 10] if n % 10 != 0 else "")
            elif n < 1000:
                return ones[n // 100] + " Hundred" + (" and " + helper(n % 100) if n % 100 != 0 else "")
            return ""

        parts = []
        crore = amt // 10000000
        if crore > 0:
            parts.append(helper(crore) + " Crore")
            amt %= 10000000
        lakh = amt // 100000
        if lakh > 0:
            parts.append(helper(lakh) + " Lakh")
            amt %= 100000
        thousand = amt // 1000
        if thousand > 0:
            parts.append(helper(thousand) + " Thousand")
            amt %= 1000
        if amt > 0:
            parts.append(helper(amt))
        return "Rupees " + " ".join(parts) + " Only"
    except Exception:
        return f"Rupees {float(amount):,.2f} Only"


class PDFGenerator:
    """
    Enterprise-Grade PDF Document Generator for Indian MSMEs:
    1. Professional GST Tax Invoice (CA-Compliant, Section 43B(h), Clean Table Grid & Bank Details).
    2. Executive AI Action Plan & Cash Flow Brief (SIIC IIT Kanpur AVINYA 2K26 Edition).
    3. Formal Payment Reminder Demand Notice (with overdue aging alerts and statutory terms).
    """

    @classmethod
    def generate_invoice_pdf(cls, inv, items, output_path):
        """Generates a high-end, CA-compliant Indian Tax Invoice PDF fitting cleanly on a single page."""
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=A4,
            rightMargin=36, leftMargin=36,
            topMargin=28, bottomMargin=28
        )
        styles = getSampleStyleSheet()
        story = []

        # Color Palette
        navy_primary = colors.HexColor('#0F2C59')
        slate_blue = colors.HexColor('#1E3A8A')
        accent_red = colors.HexColor('#DC2626')
        accent_green = colors.HexColor('#059669')
        accent_amber = colors.HexColor('#D97706')
        bg_tint = colors.HexColor('#F8FAFC')
        border_color = colors.HexColor('#CBD5E1')

        # Status Badge Color
        status = str(inv.get('payment_status', 'unpaid')).lower()
        if status == 'overdue':
            status_text = "OVERDUE — PAYMENT REQUIRED"
            status_color = accent_red
        elif status == 'paid':
            status_text = "PAID IN FULL"
            status_color = accent_green
        elif status == 'partially_paid':
            status_text = "PARTIALLY PAID"
            status_color = accent_amber
        else:
            status_text = "PENDING PAYMENT"
            status_color = slate_blue

        # Typography Styles
        title_style = ParagraphStyle('InvTitle', parent=styles['Heading1'], fontSize=18, fontName='Helvetica-Bold', textColor=navy_primary, spaceAfter=2)
        sub_title = ParagraphStyle('SubTitle', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica', textColor=colors.HexColor('#64748B'))
        badge_style = ParagraphStyle('Badge', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica-Bold', textColor=colors.white, alignment=1)
        th_white = ParagraphStyle('THW', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica-Bold', textColor=colors.white, alignment=1)
        th_white_left = ParagraphStyle('THWL', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica-Bold', textColor=colors.white, alignment=0)
        th_white_right = ParagraphStyle('THWR', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica-Bold', textColor=colors.white, alignment=2)
        td_style = ParagraphStyle('TD', parent=styles['Normal'], fontSize=8, leading=11, fontName='Helvetica', textColor=colors.HexColor('#1E293B'))
        td_center = ParagraphStyle('TDC', parent=styles['Normal'], fontSize=8, fontName='Helvetica', textColor=colors.HexColor('#1E293B'), alignment=1)
        td_num = ParagraphStyle('TDNum', parent=styles['Normal'], fontSize=8, fontName='Helvetica', textColor=colors.HexColor('#1E293B'), alignment=2)
        bold_lbl = ParagraphStyle('BLbl', parent=styles['Normal'], fontSize=8, fontName='Helvetica-Bold', textColor=colors.HexColor('#0F172A'))
        bold_num = ParagraphStyle('BNum', parent=styles['Normal'], fontSize=8.5, fontName='Helvetica-Bold', textColor=colors.HexColor('#0F172A'), alignment=2)

        # 1. Header with Company Branding & Status Badge
        badge_table = Table([[Paragraph(status_text, badge_style)]], colWidths=[180])
        badge_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), status_color),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('PADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))

        header_data = [
            [
                Paragraph("<b>TAX INVOICE</b>", title_style),
                badge_table
            ],
            [
                Paragraph("Original for Recipient | Compliant under Indian GST Act, 2017 & MSMED Act", sub_title),
                ""
            ]
        ]
        t_header = Table(header_data, colWidths=[342, 180])
        t_header.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('ALIGN', (1,0), (1,0), 'RIGHT'),
        ]))
        story.append(t_header)
        story.append(Spacer(1, 6))
        story.append(HRFlowable(width="100%", thickness=1.5, color=navy_primary, spaceAfter=8))

        # 2. Billed By / Billed To Section
        party_name = inv.get('party_name') or 'Commercial Client'
        inv_num = inv.get('invoice_number') or 'INV-DRAFT'
        inv_date = inv.get('invoice_date') or '2026-10-09'
        due_date = inv.get('due_date') or 'Immediate'
        cust_gstin = inv.get('customer_gstin') or '09ABCDE1234F1Z5'

        meta_table_data = [
            [
                Paragraph("<b>SUPPLIER / ISSUER:</b><br/>"
                          "<b>Sharma Electricals & Hardware Enterprises</b><br/>"
                          "Industrial Area, Fazalganj, Kanpur - 208012<br/>"
                          "State: Uttar Pradesh (Code: 09)<br/>"
                          "GSTIN: <b>09AAACH7409R1ZZ</b><br/>"
                          "Email: billing@sharmaelectricals.in | Phone: +91 94500-12345", td_style),
                Paragraph(f"<b>INVOICE DETAILS:</b><br/>"
                          f"Invoice No: <b>{inv_num}</b><br/>"
                          f"Invoice Date: <b>{inv_date}</b><br/>"
                          f"Due Date: <b>{due_date}</b><br/>"
                          f"Payment Terms: <b>Net 30 Days</b><br/>"
                          f"Place of Supply: <b>Uttar Pradesh (09)</b>", td_style)
            ],
            [
                Paragraph(f"<b>BILLED TO (BUYER):</b><br/>"
                          f"<b>{party_name}</b><br/>"
                          f"Address: Commercial Complex, Mall Road, Kanpur - 208001<br/>"
                          f"State: Uttar Pradesh (Code: 09)<br/>"
                          f"GSTIN: <b>{cust_gstin}</b>", td_style),
                Paragraph(f"<b>PAYMENT STATUS SUMMARY:</b><br/>"
                          f"Invoice Amount: <b>Rs. {float(inv.get('total_amount', 0)):,.2f}</b><br/>"
                          f"Amount Received: <font color='#059669'><b>Rs. {float(inv.get('amount_paid', 0)):,.2f}</b></font><br/>"
                          f"Balance Due: <font color='#DC2626'><b>Rs. {float(inv.get('balance_due', 0)):,.2f}</b></font>", td_style)
            ]
        ]
        t_meta = Table(meta_table_data, colWidths=[261, 261])
        t_meta.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), bg_tint),
            ('BOX', (0,0), (-1,-1), 1, border_color),
            ('INNERGRID', (0,0), (-1,-1), 0.5, border_color),
            ('PADDING', (0,0), (-1,-1), 6),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ]))
        story.append(t_meta)
        story.append(Spacer(1, 8))

        # 3. Items Table
        table_rows = [
            [Paragraph("<b>#</b>", th_white),
             Paragraph("<b>Item Description / Goods</b>", th_white_left),
             Paragraph("<b>HSN/SAC</b>", th_white),
             Paragraph("<b>Qty</b>", th_white),
             Paragraph("<b>Rate (Rs.)</b>", th_white_right),
             Paragraph("<b>GST %</b>", th_white),
             Paragraph("<b>Amount (Rs.)</b>", th_white_right)]
        ]

        if not items:
            items = [{"description": "Industrial Commercial Supplies", "quantity": 1, "unit_price": inv.get("subtotal", 0), "tax_rate": 18, "total_amount": inv.get("total_amount", 0)}]

        for idx, it in enumerate(items, 1):
            sub = float(it.get('quantity', 1)) * float(it.get('unit_price', 0))
            table_rows.append([
                Paragraph(str(idx), td_center),
                Paragraph(str(it.get('description', 'Item')), td_style),
                Paragraph(str(it.get('hsn_code', '8536')), td_center),
                Paragraph(str(it.get('quantity', 1)), td_center),
                Paragraph(f"{float(it.get('unit_price', 0)):,.2f}", td_num),
                Paragraph(f"{float(it.get('tax_rate', 18)):.0f}%", td_center),
                Paragraph(f"{sub:,.2f}", td_num),
            ])

        t_items = Table(table_rows, colWidths=[24, 210, 52, 38, 68, 42, 88])
        t_items.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), navy_primary),
            ('BOX', (0,0), (-1,-1), 1, border_color),
            ('INNERGRID', (0,0), (-1,-1), 0.5, border_color),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, bg_tint]),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('PADDING', (0,0), (-1,-1), 4.5),
        ]))
        story.append(t_items)

        # 4. Integrated Clean Totals & Terms Summary (Zero floating/broken lines)
        subtotal = float(inv.get('subtotal', 0))
        tax_total = float(inv.get('tax_amount', 0))
        grand_total = float(inv.get('total_amount', 0))
        paid = float(inv.get('amount_paid', 0))
        balance = float(inv.get('balance_due', 0))
        cgst = tax_total / 2.0
        sgst = tax_total / 2.0

        words_text = amount_to_indian_words(grand_total)
        left_notes = Paragraph(
            f"<b>Amount Chargeable (in words):</b><br/>"
            f"<font color='#0F2C59'><b>{words_text}</b></font><br/><br/>"
            f"<b>Terms & Conditions:</b><br/>"
            f"<font size=7 color='#64748B'>"
            f"1. Goods once inspected and accepted will not be taken back.<br/>"
            f"2. Governed by MSMED Act 2006 & Section 43B(h). Payment due within credit period.<br/>"
            f"3. All disputes subject to Kanpur Jurisdiction only."
            f"</font>", td_style
        )

        summary_rows = [
            [left_notes, Paragraph("Taxable Value:", td_style), Paragraph(f"Rs. {subtotal:,.2f}", td_num)],
            ["", Paragraph("CGST (9.0%):", td_style), Paragraph(f"Rs. {cgst:,.2f}", td_num)],
            ["", Paragraph("SGST (9.0%):", td_style), Paragraph(f"Rs. {sgst:,.2f}", td_num)],
            ["", Paragraph("Total Tax Amount:", td_style), Paragraph(f"Rs. {tax_total:,.2f}", td_num)],
            ["", Paragraph("<b>Invoice Total:</b>", bold_lbl), Paragraph(f"<b>Rs. {grand_total:,.2f}</b>", bold_num)],
            ["", Paragraph("Amount Received:", td_style), Paragraph(f"Rs. {paid:,.2f}", td_num)],
            ["", Paragraph("<b>Net Balance Due:</b>", ParagraphStyle('BalLbl', parent=bold_lbl, textColor=accent_red if balance > 0 else accent_green)),
                 Paragraph(f"<b>Rs. {balance:,.2f}</b>", ParagraphStyle('BalNum', parent=bold_num, textColor=accent_red if balance > 0 else accent_green))]
        ]

        t_summary = Table(summary_rows, colWidths=[324, 108, 90])
        t_summary.setStyle(TableStyle([
            ('SPAN', (0, 0), (0, -1)),  # Span entire left column for words and terms
            ('BOX', (0, 0), (-1, -1), 1, border_color),
            ('INNERGRID', (1, 0), (-1, -1), 0.5, border_color),
            ('LINEAFTER', (0, 0), (0, -1), 1, border_color),
            ('BACKGROUND', (0, 0), (0, -1), bg_tint),
            ('BACKGROUND', (1, 4), (-1, 4), colors.HexColor('#F1F5F9')),
            ('BACKGROUND', (1, -1), (-1, -1), colors.HexColor('#FEF2F2') if balance > 0 else colors.HexColor('#ECFDF5')),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('VALIGN', (0, 0), (0, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 4),
        ]))
        story.append(t_summary)
        story.append(Spacer(1, 8))

        # 5. Bank Account & Remittance QR Block
        bank_data = [
            [
                Paragraph("<b>BANK DETAILS (RTGS / NEFT / IMPS):</b><br/>"
                          "Bank: <b>State Bank of India (SBI)</b><br/>"
                          "A/C Name: <b>Sharma Electricals & Hardware Enterprises</b><br/>"
                          "A/C No: <b>384729104829</b> | IFSC: <b>SBIN0001234</b><br/>"
                          "Branch: Main Branch, Kanpur | UPI ID: <b>sharmaelectricals@sbi</b>", td_style),
                Paragraph("<para align=center><b>SCAN TO PAY VIA UPI</b><br/>"
                          "<font size=7 color='#64748B'>GPay / PhonePe / Paytm / BHIM</font><br/>"
                          "<b>[ UPI QR CODE ]</b><br/>"
                          "<font size=7 color='#059669'>Instant Settlement</font></para>", td_style),
                Paragraph("<para align=center>For <b>Sharma Electricals & Hardware</b><br/><br/><br/>"
                          "<b>Authorized Signatory</b><br/>"
                          "<font size=7 color='#64748B'>Computer Generated Invoice</font></para>", td_style)
            ]
        ]
        t_bank = Table(bank_data, colWidths=[242, 140, 140])
        t_bank.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), bg_tint),
            ('BOX', (0,0), (-1,-1), 1, border_color),
            ('INNERGRID', (0,0), (-1,-1), 0.5, border_color),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('PADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_bank)
        story.append(Spacer(1, 6))

        # Statutory Footer
        story.append(Paragraph("<font size=7 color='#94A3B8'>* MSME Compliance: Governed by Section 43B(h) of the Income Tax Act & MSMED Act 2006. Invoices overdue beyond agreed credit period are subject to compound interest as mandated by law. Kanpur Jurisdiction.</font>", td_style))

        doc.build(story)
        return str(output_path)

    @classmethod
    def generate_action_plan_pdf(cls, plan_data, output_path):
        """Generates an Executive AI Action Plan with high visual polish."""
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=A4,
            rightMargin=36, leftMargin=36,
            topMargin=36, bottomMargin=36
        )
        styles = getSampleStyleSheet()
        story = []

        navy_primary = colors.HexColor('#0F2C59')
        slate_blue = colors.HexColor('#1E3A8A')
        accent_red = colors.HexColor('#DC2626')
        accent_green = colors.HexColor('#059669')
        border_color = colors.HexColor('#CBD5E1')

        title_style = ParagraphStyle('Title', parent=styles['Heading1'], fontSize=18, fontName='Helvetica-Bold', textColor=navy_primary, spaceAfter=2)
        meta_style = ParagraphStyle('Meta', parent=styles['Normal'], fontSize=9, textColor=colors.HexColor('#64748B'), spaceAfter=10)
        h2_style = ParagraphStyle('H2', parent=styles['Heading2'], fontSize=12, fontName='Helvetica-Bold', textColor=slate_blue, spaceAfter=8)
        body = ParagraphStyle('Body', parent=styles['Normal'], fontSize=9, leading=13, textColor=colors.HexColor('#1E293B'))
        bold_lbl = ParagraphStyle('BLbl', parent=styles['Normal'], fontSize=9, fontName='Helvetica-Bold', textColor=colors.HexColor('#0F172A'))

        # Header Banner
        story.append(Paragraph("<b>VyaparAI — Executive Action Plan & Cash Flow Brief</b>", title_style))
        story.append(Paragraph(f"Business: <b>{plan_data.get('business_name')}</b> | Reference Date: <b>{plan_data.get('reference_date')}</b> | SIIC, IIT Kanpur AVINYA 2K26 Edition", meta_style))
        story.append(HRFlowable(width="100%", thickness=2, color=navy_primary, spaceAfter=12))

        # KPI Metrics Summary Cards
        metrics = plan_data.get('metrics', {})
        kpi_data = [
            [
                Paragraph("<para align=center><font size=8 color='#64748B'>TOTAL INVOICED</font><br/><font size=13 color='#0F172A'><b>Rs. {:,.2f}</b></font></para>".format(metrics.get('total_invoiced', 0)), body),
                Paragraph("<para align=center><font size=8 color='#64748B'>PAYMENTS COLLECTED</font><br/><font size=13 color='#059669'><b>Rs. {:,.2f}</b></font></para>".format(metrics.get('total_received', 0)), body),
                Paragraph("<para align=center><font size=8 color='#64748B'>ACTIVE RECEIVABLES</font><br/><font size=13 color='#D97706'><b>Rs. {:,.2f}</b></font></para>".format(metrics.get('total_outstanding', 0)), body),
                Paragraph("<para align=center><font size=8 color='#64748B'>CRITICAL OVERDUE</font><br/><font size=13 color='#DC2626'><b>Rs. {:,.2f}</b></font></para>".format(metrics.get('total_overdue', 0)), body)
            ]
        ]
        kpi_table = Table(kpi_data, colWidths=[130, 130, 130, 130])
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
            ('BOX', (0,0), (-1,-1), 1, border_color),
            ('INNERGRID', (0,0), (-1,-1), 0.5, border_color),
            ('ALIGN', (0,0), (-1,-1), 'CENTER'),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('PADDING', (0,0), (-1,-1), 8),
        ]))
        story.append(kpi_table)
        story.append(Spacer(1, 14))

        # Prioritized Action Items
        story.append(Paragraph("<b>PRIORITIZED BUSINESS ACTION ITEMS (EVIDENCE-GROUNDED)</b>", h2_style))

        recommendations = plan_data.get('recommendations', [])
        for idx, r in enumerate(recommendations, 1):
            is_high = r.get('priority') == 'high'
            box_data = [
                [
                    Paragraph(f"<b>Priority #{idx}: {r.get('finding')}</b>", ParagraphStyle('RecT', parent=styles['Normal'], fontSize=10, fontName='Helvetica-Bold', textColor=accent_red if is_high else slate_blue)),
                    Paragraph(f"<para align=right><font size=8 color='{'#DC2626' if is_high else '#D97706'}'><b>{r.get('priority', 'high').upper()} PRIORITY</b></font></para>", body)
                ],
                [
                    Paragraph(f"<b>Verified Facts:</b> {r.get('verified_facts')}", body),
                    ""
                ],
                [
                    Paragraph(f"<b>Supporting Evidence:</b> {r.get('supporting_evidence')}", body),
                    ""
                ],
                [
                    Paragraph(f"<b>Recommended Action:</b> {r.get('recommended_action')}", body),
                    ""
                ],
                [
                    Paragraph(f"<b>Expected Financial Impact:</b> <font color='#059669'><b>{r.get('expected_impact')}</b></font>", body),
                    ""
                ]
            ]
            t_box = Table(box_data, colWidths=[420, 100])
            t_box.setStyle(TableStyle([
                ('SPAN', (0, 1), (1, 1)),
                ('SPAN', (0, 2), (1, 2)),
                ('SPAN', (0, 3), (1, 3)),
                ('SPAN', (0, 4), (1, 4)),
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#FFF9F9') if is_high else colors.HexColor('#F8FAFC')),
                ('BOX', (0,0), (-1,-1), 1, accent_red if is_high else border_color),
                ('PADDING', (0,0), (-1,-1), 6),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ]))
            story.append(KeepTogether(t_box))
            story.append(Spacer(1, 10))

        doc.build(story)
        return str(output_path)

    @classmethod
    def generate_reminder_pdf(cls, reminder_data, output_path):
        """Generates a formal demand notice letter PDF."""
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=A4,
            rightMargin=40, leftMargin=40,
            topMargin=40, bottomMargin=40
        )
        styles = getSampleStyleSheet()
        story = []

        navy = colors.HexColor('#0F2C59')
        red = colors.HexColor('#DC2626')
        border = colors.HexColor('#CBD5E1')

        title_style = ParagraphStyle('Title', parent=styles['Heading1'], fontSize=18, fontName='Helvetica-Bold', textColor=navy, spaceAfter=2)
        sub_style = ParagraphStyle('Sub', parent=styles['Normal'], fontSize=9, fontName='Helvetica', textColor=colors.HexColor('#64748B'), spaceAfter=12)
        body = ParagraphStyle('Body', parent=styles['Normal'], fontSize=9.5, leading=15, fontName='Helvetica', textColor=colors.HexColor('#1E293B'), spaceAfter=8)
        highlight = ParagraphStyle('HL', parent=styles['Normal'], fontSize=9.5, fontName='Helvetica-Bold', textColor=red)

        # Letterhead
        story.append(Paragraph(f"<b>{reminder_data.get('business_name', 'Sharma Electricals & Hardware Enterprises')}</b>", title_style))
        story.append(Paragraph("Commercial Billing & Accounts Receivable Desk | Registered MSME", sub_style))
        story.append(HRFlowable(width="100%", thickness=2, color=navy, spaceAfter=15))

        # Title
        story.append(Paragraph("<b>FORMAL PAYMENT REMINDER & OVERDUE SETTLEMENT NOTICE</b>", ParagraphStyle('Notice', parent=styles['Heading2'], fontSize=12, fontName='Helvetica-Bold', textColor=red, alignment=1, spaceAfter=15)))

        # Summary Table
        bal = float(reminder_data.get('balance_due', 0))
        meta_rows = [
            [Paragraph("<b>Date of Notice:</b>", body), Paragraph(str(reminder_data.get('date', 'Today')), body)],
            [Paragraph("<b>Customer Name:</b>", body), Paragraph(f"<b>{reminder_data.get('customer_name', '')}</b>", body)],
            [Paragraph("<b>Invoice Number:</b>", body), Paragraph(f"<b>#{reminder_data.get('invoice_number', '')}</b>", body)],
            [Paragraph("<b>Original Due Date:</b>", body), Paragraph(f"<font color='#DC2626'><b>{reminder_data.get('due_date', '')}</b></font>", body)],
            [Paragraph("<b>Total Outstanding:</b>", body), Paragraph(f"<font size=11 color='#DC2626'><b>Rs. {bal:,.2f}</b></font>", highlight)],
        ]
        t_meta = Table(meta_rows, colWidths=[150, 360])
        t_meta.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
            ('BOX', (0,0), (-1,-1), 1, border),
            ('INNERGRID', (0,0), (-1,-1), 0.5, border),
            ('PADDING', (0,0), (-1,-1), 6),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ]))
        story.append(t_meta)
        story.append(Spacer(1, 16))

        # Body Message
        reminder_text = reminder_data.get('reminder_text', '')
        for p in reminder_text.split('\n'):
            p_strip = p.strip()
            if p_strip:
                story.append(Paragraph(p_strip, body))

        story.append(Spacer(1, 15))
        story.append(Paragraph("<b>Bank Remittance Details:</b><br/>"
                               "State Bank of India (SBI) | A/C: 384729104829 | IFSC: SBIN0001234 | UPI: sharmaelectricals@sbi", body))
        story.append(Spacer(1, 20))
        story.append(Paragraph(f"Sincerely,<br/><b>Accounts Department</b><br/>{reminder_data.get('business_name', 'Sharma Electricals & Hardware')}", body))

        doc.build(story)
        return str(output_path)

pdf_generator = PDFGenerator()
