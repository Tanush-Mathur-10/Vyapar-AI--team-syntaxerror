import os
import re
import csv
import json
import uuid
import datetime
from pathlib import Path
from decimal import Decimal, InvalidOperation
from PIL import Image
import pypdf
import pandas as pd
from config import Config

class DocumentParser:
    """
    Robust document extraction engine supporting PDF, CSV, and image invoices.
    Applies pattern matching tailored to Indian MSME formats (GSTIN, INR, Net terms).
    Never invents missing values; flags uncertainty for user review.
    """

    @staticmethod
    def extract_pdf(file_path):
        """Extracts text page by page from a PDF file."""
        pages_text = []
        try:
            reader = pypdf.PdfReader(str(file_path))
            for i, page in enumerate(reader.pages):
                text = page.extract_text() or ""
                pages_text.append({
                    "page_number": i + 1,
                    "text": text.strip()
                })
            full_text = "\n\n".join([f"--- Page {p['page_number']} ---\n{p['text']}" for p in pages_text])
            return {
                "success": True,
                "full_text": full_text,
                "pages": pages_text,
                "page_count": len(pages_text)
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"PDF parsing error: {str(e)}",
                "full_text": "",
                "pages": [],
                "page_count": 0
            }

    @staticmethod
    def extract_csv(file_path):
        """Extracts tabular records from CSV file."""
        try:
            df = pd.read_csv(str(file_path))
            # Clean column names
            df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
            
            # Convert to text representation for RAG chunks
            records = df.to_dict(orient="records")
            text_lines = []
            for idx, r in enumerate(records, 1):
                line = f"Record #{idx}: " + ", ".join([f"{k}: {v}" for k, v in r.items() if pd.notna(v)])
                text_lines.append(line)
            full_text = "\n".join(text_lines)

            return {
                "success": True,
                "full_text": full_text,
                "records": records,
                "columns": list(df.columns),
                "row_count": len(df),
                "page_count": 1
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"CSV parsing error: {str(e)}",
                "full_text": "",
                "records": [],
                "columns": [],
                "row_count": 0,
                "page_count": 0
            }

    @staticmethod
    def extract_image(file_path):
        """Processes image invoices, extracts metadata and runs OCR if available."""
        try:
            img = Image.open(str(file_path))
            width, height = img.size
            format_name = img.format

            # Attempt pytesseract if installed
            text = ""
            ocr_available = False
            try:
                import pytesseract
                text = pytesseract.image_to_string(img)
                ocr_available = True
            except (ImportError, Exception):
                text = f"[Image Invoice: {Path(file_path).name} (Dimensions: {width}x{height}, Format: {format_name}) - OCR scanner not configured in local environment]"

            return {
                "success": True,
                "full_text": text.strip(),
                "width": width,
                "height": height,
                "ocr_available": ocr_available,
                "page_count": 1
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Image processing error: {str(e)}",
                "full_text": "",
                "page_count": 0
            }

    @classmethod
    def parse_document(cls, file_path, original_filename):
        """Top-level document parser returning text, metadata and structured fields."""
        ext = Path(original_filename).suffix.lower().replace(".", "")
        if ext == "pdf":
            result = cls.extract_pdf(file_path)
            doc_type = "pdf"
        elif ext == "csv":
            result = cls.extract_csv(file_path)
            doc_type = "csv"
        elif ext in ["png", "jpg", "jpeg"]:
            result = cls.extract_image(file_path)
            doc_type = "image"
        else:
            return {"success": False, "error": f"Unsupported file extension: {ext}"}

        if not result.get("success"):
            return result

        # Extract structured invoice fields from text/csv
        if doc_type == "csv":
            extracted_fields = cls._extract_from_csv_records(result.get("records", []))
        else:
            extracted_fields = cls._extract_invoice_fields_from_text(result.get("full_text", ""))

        result["doc_type"] = doc_type
        result["extracted_fields"] = extracted_fields
        return result

    @classmethod
    def _extract_invoice_fields_from_text(cls, text):
        """
        Extracts key invoice entities with regex matching for Indian commercial invoices.
        Flags uncertain or missing values rather than hallucinating.
        """
        fields = {
            "invoice_number": None,
            "party_name": None,
            "party_type": "customer", # customer or supplier
            "invoice_date": None,
            "due_date": None,
            "subtotal": 0.0,
            "tax_amount": 0.0,
            "discount_amount": 0.0,
            "total_amount": 0.0,
            "amount_paid": 0.0,
            "balance_due": 0.0,
            "payment_status": "unpaid",
            "is_uncertain": False,
            "uncertain_reasons": []
        }

        if not text:
            fields["is_uncertain"] = True
            fields["uncertain_reasons"].append("Document text is empty or unreadable.")
            return fields

        # 1. Invoice Number patterns
        inv_match = re.search(r'(?:invoice|bill|inv)[\s\.\-\#\:\_]+([A-Za-z0-9\-\/]{3,25})', text, re.IGNORECASE)
        if inv_match:
            fields["invoice_number"] = inv_match.group(1).strip()
        else:
            # Fallback simple pattern like INV-2026-001
            simple_inv = re.search(r'\b(INV[-_]?[0-9]{3,8}|BILL[-_]?[0-9]{3,8})\b', text, re.IGNORECASE)
            if simple_inv:
                fields["invoice_number"] = simple_inv.group(1).strip()
            else:
                fields["is_uncertain"] = True
                fields["uncertain_reasons"].append("Invoice Number could not be detected with high confidence.")

        # 2. Party Name (Billed To / Customer / Client)
        party_match = re.search(r'(?:bill\s+to|billed\s+to|customer\s+name|buyer|m\/s|to\s*:)\s*[\:\-]?\s*([A-Za-z0-9\s\&\.\,\-\'\(\)]+?)(?:\n|gstin|phone|address|invoice)', text, re.IGNORECASE)
        if party_match:
            name = party_match.group(1).strip()
            if len(name) > 2 and len(name) < 100:
                fields["party_name"] = name
        
        if not fields["party_name"]:
            # Check for supplier indicator (Tax Invoice from Supplier)
            vendor_match = re.search(r'(?:from|vendor|supplier|seller)\s*[\:\-]?\s*([A-Za-z0-9\s\&\.\,\-\'\(\)]+?)(?:\n|gstin|phone|invoice)', text, re.IGNORECASE)
            if vendor_match:
                fields["party_name"] = vendor_match.group(1).strip()
                fields["party_type"] = "supplier"

        if not fields["party_name"]:
            fields["is_uncertain"] = True
            fields["uncertain_reasons"].append("Customer/Supplier name not clearly detected.")

        # 3. Dates (Invoice Date and Due Date)
        # Look for dates in formats: DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD, or DD Month YYYY
        date_patterns = [
            r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})',
            r'(\d{1,2}[-/]\d{1,2}[-/]\d{4})',
            r'(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})'
        ]

        # Invoice Date
        inv_date_match = re.search(r'(?:invoice\s*date|dated|bill\s*date|date)[\s\:\-]+([^\n,]+)', text, re.IGNORECASE)
        if inv_date_match:
            candidate = inv_date_match.group(1).strip()
            parsed_date = cls._parse_date_string(candidate)
            if parsed_date:
                fields["invoice_date"] = parsed_date

        if not fields["invoice_date"]:
            # Search anywhere in first 500 chars for any valid date
            for pat in date_patterns:
                m = re.search(pat, text[:600], re.IGNORECASE)
                if m:
                    parsed = cls._parse_date_string(m.group(1))
                    if parsed:
                        fields["invoice_date"] = parsed
                        break

        if not fields["invoice_date"]:
            fields["invoice_date"] = datetime.date.today().isoformat()
            fields["is_uncertain"] = True
            fields["uncertain_reasons"].append("Invoice date missing; defaulted to current date for review.")

        # Due Date
        due_date_match = re.search(r'(?:due\s*date|payment\s*due|pay\s*by)[\s\:\-]+([^\n,]+)', text, re.IGNORECASE)
        if due_date_match:
            candidate = due_date_match.group(1).strip()
            parsed_due = cls._parse_date_string(candidate)
            if parsed_due:
                fields["due_date"] = parsed_due

        # If due date is missing, do NOT invent one! Per requirements:
        # "Do not mark an invoice as overdue if its due date is missing."
        # If missing, keep as None, or flag if terms are known.
        if not fields["due_date"]:
            # Check for Net 30, Net 15
            net_match = re.search(r'net\s*(\d{1,3})', text, re.IGNORECASE)
            if net_match and fields["invoice_date"]:
                days = int(net_match.group(1))
                try:
                    inv_d = datetime.date.fromisoformat(fields["invoice_date"])
                    fields["due_date"] = (inv_d + datetime.timedelta(days=days)).isoformat()
                except Exception:
                    fields["due_date"] = None
            else:
                fields["due_date"] = None

        # 4. Financial Amounts (Total, Subtotal, Tax, Paid, Balance)
        # Search for Total
        total_patterns = [
            r'(?:grand\s+total|total\s+amount|invoice\s+total|net\s+total|total)[\s\:\-₹rs\.]*([\d\.\,]{2,12})',
            r'₹\s*([\d\.\,]{2,12})'
        ]
        for pat in total_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                val = cls._clean_number(m.group(1))
                if val and val > 0:
                    fields["total_amount"] = val
                    break

        # Search for Subtotal
        sub_match = re.search(r'(?:subtotal|sub\s+total|taxable\s+value|taxable\s+amount)[\s\:\-₹rs\.]*([\d\.\,]{2,12})', text, re.IGNORECASE)
        if sub_match:
            fields["subtotal"] = cls._clean_number(sub_match.group(1)) or 0.0

        # Search for Tax / GST
        tax_match = re.search(r'(?:total\s+tax|gst|igst|cgst\s*\+\s*sgst|tax)[\s\:\-₹rs\.]*([\d\.\,]{2,12})', text, re.IGNORECASE)
        if tax_match:
            fields["tax_amount"] = cls._clean_number(tax_match.group(1)) or 0.0

        # Search for Amount Paid
        paid_match = re.search(r'(?:amount\s+paid|paid\s+amount|payment\s+received|advance)[\s\:\-₹rs\.]*([\d\.\,]{2,12})', text, re.IGNORECASE)
        if paid_match:
            fields["amount_paid"] = cls._clean_number(paid_match.group(1)) or 0.0

        # Search for Balance Due / Outstanding
        bal_match = re.search(r'(?:balance\s+due|outstanding|balance\s+amount|amount\s+due)[\s\:\-₹rs\.]*([\d\.\,]{2,12})', text, re.IGNORECASE)
        if bal_match:
            fields["balance_due"] = cls._clean_number(bal_match.group(1)) or 0.0
        else:
            # Calculate from total and amount paid
            fields["balance_due"] = max(0.0, fields["total_amount"] - fields["amount_paid"])

        # Sanity check total vs subtotal
        if fields["total_amount"] == 0.0 and fields["subtotal"] > 0:
            fields["total_amount"] = fields["subtotal"] + fields["tax_amount"]
            fields["balance_due"] = max(0.0, fields["total_amount"] - fields["amount_paid"])

        if fields["total_amount"] == 0.0:
            fields["is_uncertain"] = True
            fields["uncertain_reasons"].append("Total invoice amount could not be detected.")

        # Payment Status calculation
        if fields["balance_due"] <= 0.0 and fields["total_amount"] > 0:
            fields["payment_status"] = "paid"
        elif fields["amount_paid"] > 0 and fields["balance_due"] > 0:
            fields["payment_status"] = "partially_paid"
        else:
            fields["payment_status"] = "unpaid"

        return fields

    @classmethod
    def _extract_from_csv_records(cls, records):
        """Extracts structured invoice rows from CSV records."""
        parsed_invoices = []
        for r in records:
            inv = {
                "invoice_number": str(r.get("invoice_number") or r.get("invoice_no") or r.get("inv_no") or r.get("bill_no") or f"INV-CSV-{uuid.uuid4().hex[:6].upper()}"),
                "party_name": str(r.get("customer") or r.get("customer_name") or r.get("party_name") or r.get("client") or r.get("vendor") or "Unknown Party"),
                "party_type": "customer" if not any(k in str(r.get("type", "")).lower() for k in ["purchase", "vendor", "supplier"]) else "supplier",
                "invoice_date": cls._parse_date_string(str(r.get("invoice_date") or r.get("date") or datetime.date.today().isoformat())),
                "due_date": cls._parse_date_string(str(r.get("due_date") or r.get("payment_due") or "")) if r.get("due_date") else None,
                "subtotal": cls._clean_number(r.get("subtotal") or r.get("taxable_amount") or 0.0),
                "tax_amount": cls._clean_number(r.get("tax_amount") or r.get("gst") or r.get("tax") or 0.0),
                "discount_amount": cls._clean_number(r.get("discount") or 0.0),
                "total_amount": cls._clean_number(r.get("total_amount") or r.get("total") or r.get("amount") or 0.0),
                "amount_paid": cls._clean_number(r.get("amount_paid") or r.get("paid") or 0.0),
                "balance_due": 0.0,
                "payment_status": "unpaid",
                "is_uncertain": False,
                "uncertain_reasons": []
            }
            # Balance
            if "balance_due" in r and r.get("balance_due") is not None:
                inv["balance_due"] = cls._clean_number(r.get("balance_due"))
            else:
                inv["balance_due"] = max(0.0, inv["total_amount"] - inv["amount_paid"])

            # Status
            if inv["balance_due"] <= 0.0 and inv["total_amount"] > 0:
                inv["payment_status"] = "paid"
            elif inv["amount_paid"] > 0 and inv["balance_due"] > 0:
                inv["payment_status"] = "partially_paid"
            else:
                inv["payment_status"] = "unpaid"

            parsed_invoices.append(inv)
        return parsed_invoices

    @staticmethod
    def _clean_number(val):
        """Converts strings with currency symbols or commas to float."""
        if val is None:
            return 0.0
        if isinstance(val, (int, float)):
            return float(val)
        val_str = str(val).replace("₹", "").replace("Rs.", "").replace("Rs", "").replace(",", "").replace("/-", "").strip()
        try:
            return float(val_str)
        except ValueError:
            return 0.0

    @staticmethod
    def _parse_date_string(val):
        """Parses various date string formats into standard YYYY-MM-DD."""
        if not val:
            return None
        val = str(val).strip()
        formats = [
            "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
            "%d %b %Y", "%d %B %Y", "%Y/%m/%d", "%d.%m.%Y"
        ]
        for fmt in formats:
            try:
                dt = datetime.datetime.strptime(val, fmt)
                return dt.date().isoformat()
            except ValueError:
                continue
        # ISO check
        try:
            return datetime.date.fromisoformat(val).isoformat()
        except Exception:
            return None
