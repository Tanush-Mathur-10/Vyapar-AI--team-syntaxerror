import datetime
from decimal import Decimal
from config import Config
from core.db import db

class FinancialEngine:
    """
    Deterministic Financial Calculation Engine for VyaparAI.
    Computes exact business metrics directly from verified database records.
    Strictly follows MSME accounting rules:
    - Never marks an invoice overdue if due date is missing.
    - Never treats a fully paid invoice as overdue.
    - Accurately tracks partial payments.
    - Excludes cancelled/void invoices.
    """

    @classmethod
    def get_reference_date(cls, override_date=None):
        """Returns the reference date for overdue calculations."""
        if override_date:
            try:
                return datetime.date.fromisoformat(override_date)
            except Exception:
                pass
        if Config.DEMO_REFERENCE_DATE:
            try:
                return datetime.date.fromisoformat(Config.DEMO_REFERENCE_DATE)
            except Exception:
                pass
        return datetime.date.today()

    @classmethod
    def get_dashboard_metrics(cls, business_id, ref_date=None):
        """
        Calculates all high-level business indicators for the Action Center.
        """
        reference_date = cls.get_reference_date(ref_date)
        ref_date_str = reference_date.isoformat()

        # Update dynamic payment_status for all active invoices
        cls.refresh_invoice_statuses(business_id, reference_date)

        # 1. Total Invoiced (Sales)
        sales_sql = """
        SELECT 
            COALESCE(SUM(total_amount), 0) as total_invoiced,
            COALESCE(SUM(amount_paid), 0) as total_received,
            COALESCE(SUM(balance_due), 0) as total_outstanding,
            COUNT(*) as total_invoices_count
        FROM invoices
        WHERE business_id = %s 
          AND invoice_type = 'sale'
          AND payment_status != 'cancelled'
        """
        sales_stats = db.execute_one(sales_sql, (business_id,)) or {}

        # 2. Overdue Invoices Calculation
        # An invoice is overdue ONLY IF:
        # a) balance_due > 0
        # b) due_date IS NOT NULL
        # c) due_date < reference_date
        # d) status is not cancelled
        overdue_sql = """
        SELECT 
            COALESCE(SUM(balance_due), 0) as total_overdue,
            COUNT(*) as overdue_count
        FROM invoices
        WHERE business_id = %s 
          AND invoice_type = 'sale'
          AND balance_due > 0
          AND due_date IS NOT NULL
          AND due_date < %s
          AND payment_status != 'cancelled'
        """
        overdue_stats = db.execute_one(overdue_sql, (business_id, ref_date_str)) or {}

        # 3. Accounts Payable (Purchases/Bills from suppliers)
        payable_sql = """
        SELECT 
            COALESCE(SUM(total_amount), 0) as total_bills,
            COALESCE(SUM(balance_due), 0) as total_payable
        FROM invoices
        WHERE business_id = %s 
          AND invoice_type = 'purchase'
          AND payment_status != 'cancelled'
        """
        payable_stats = db.execute_one(payable_sql, (business_id,)) or {}

        # 4. Status counts
        status_counts_sql = """
        SELECT payment_status, COUNT(*) as cnt
        FROM invoices
        WHERE business_id = %s AND invoice_type = 'sale'
        GROUP BY payment_status
        """
        raw_status = db.execute_query(status_counts_sql, (business_id,))
        status_dist = {r["payment_status"]: r["cnt"] for r in raw_status}

        return {
            "reference_date": ref_date_str,
            "total_invoiced": round(float(sales_stats.get("total_invoiced", 0.0)), 2),
            "total_received": round(float(sales_stats.get("total_received", 0.0)), 2),
            "total_outstanding": round(float(sales_stats.get("total_outstanding", 0.0)), 2),
            "total_overdue": round(float(overdue_stats.get("total_overdue", 0.0)), 2),
            "overdue_count": int(overdue_stats.get("overdue_count", 0)),
            "total_invoices_count": int(sales_stats.get("total_invoices_count", 0)),
            "accounts_payable": round(float(payable_stats.get("total_payable", 0.0)), 2),
            "status_distribution": status_dist
        }

    @classmethod
    def get_overdue_invoices(cls, business_id, ref_date=None):
        """
        Retrieves all overdue invoices with exact days overdue and source document info.
        """
        reference_date = cls.get_reference_date(ref_date)
        ref_date_str = reference_date.isoformat()

        sql = """
        SELECT i.id, i.invoice_number, i.party_name, i.party_id, i.invoice_date, i.due_date,
               i.total_amount, i.amount_paid, i.balance_due, i.payment_status, i.is_uncertain,
               d.original_filename as document_filename, d.id as document_id
        FROM invoices i
        LEFT JOIN documents d ON i.document_id = d.id
        WHERE i.business_id = %s
          AND i.invoice_type = 'sale'
          AND i.balance_due > 0
          AND i.due_date IS NOT NULL
          AND i.due_date < %s
          AND i.payment_status != 'cancelled'
        ORDER BY i.balance_due DESC
        """
        rows = db.execute_query(sql, (business_id, ref_date_str))

        for row in rows:
            # Calculate days overdue
            if row.get("due_date"):
                try:
                    d_due = datetime.date.fromisoformat(str(row["due_date"])[:10])
                    row["days_overdue"] = max(0, (reference_date - d_due).days)
                except Exception:
                    row["days_overdue"] = 0
            else:
                row["days_overdue"] = 0

            # Categorize overdue risk bucket
            days = row["days_overdue"]
            if days > 45:
                row["risk_level"] = "Critical"
                row["urgency_class"] = "danger"
            elif days > 15:
                row["risk_level"] = "High"
                row["urgency_class"] = "warning"
            else:
                row["risk_level"] = "Moderate"
                row["urgency_class"] = "info"

        return rows

    @classmethod
    def get_customer_aging(cls, business_id, ref_date=None):
        """
        Aggregates customer payment health and aging buckets (0-30 days, 31-60 days, 60+ days).
        """
        reference_date = cls.get_reference_date(ref_date)
        ref_date_str = reference_date.isoformat()

        sql = """
        SELECT party_name,
               COUNT(*) as total_invoices,
               SUM(total_amount) as total_billed,
               SUM(amount_paid) as total_paid,
               SUM(balance_due) as total_pending
        FROM invoices
        WHERE business_id = %s AND invoice_type = 'sale' AND payment_status != 'cancelled'
        GROUP BY party_name
        ORDER BY total_pending DESC
        """
        customers = db.execute_query(sql, (business_id,))

        for cust in customers:
            # Overdue for this customer
            c_overdue_sql = """
            SELECT SUM(balance_due) as overdue_amt, COUNT(*) as overdue_count
            FROM invoices
            WHERE business_id = %s AND party_name = %s
              AND balance_due > 0 AND due_date IS NOT NULL AND due_date < %s
            """
            od = db.execute_one(c_overdue_sql, (business_id, cust["party_name"], ref_date_str)) or {}
            cust["overdue_amount"] = round(float(od.get("overdue_amt") or 0.0), 2)
            cust["overdue_invoices"] = int(od.get("overdue_count") or 0)
            
            # Reliability score (paid / billed ratio)
            billed = float(cust.get("total_billed") or 0.0)
            paid = float(cust.get("total_paid") or 0.0)
            if billed > 0:
                cust["reliability_score"] = round((paid / billed) * 100, 1)
            else:
                cust["reliability_score"] = 100.0

        return customers

    @classmethod
    def refresh_invoice_statuses(cls, business_id, reference_date):
        """
        Updates payment_status in database for all invoices based on reference date and balances.
        """
        ref_date_str = reference_date.isoformat()
        
        # 1. Fully paid invoices
        sql_paid = """
        UPDATE invoices
        SET payment_status = 'paid'
        WHERE business_id = %s AND balance_due <= 0 AND total_amount > 0 AND payment_status != 'cancelled'
        """
        db.execute_commit(sql_paid, (business_id,))

        # 2. Overdue invoices
        sql_overdue = """
        UPDATE invoices
        SET payment_status = 'overdue'
        WHERE business_id = %s 
          AND balance_due > 0 
          AND due_date IS NOT NULL 
          AND due_date < %s 
          AND payment_status != 'cancelled'
        """
        db.execute_commit(sql_overdue, (business_id, ref_date_str))

        # 3. Partially paid (not overdue)
        sql_partial = """
        UPDATE invoices
        SET payment_status = 'partially_paid'
        WHERE business_id = %s 
          AND amount_paid > 0 
          AND balance_due > 0 
          AND (due_date IS NULL OR due_date >= %s)
          AND payment_status != 'cancelled'
        """
        db.execute_commit(sql_partial, (business_id, ref_date_str))

        # 4. Unpaid (not overdue)
        sql_unpaid = """
        UPDATE invoices
        SET payment_status = 'unpaid'
        WHERE business_id = %s 
          AND amount_paid = 0 
          AND balance_due > 0 
          AND (due_date IS NULL OR due_date >= %s)
          AND payment_status != 'cancelled'
        """
        db.execute_commit(sql_unpaid, (business_id, ref_date_str))

financial_engine = FinancialEngine()
