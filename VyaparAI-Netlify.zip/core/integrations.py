import os
import smtplib
import urllib.parse
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import Config
from core.db import db

class IntegrationManager:
    """
    Manages external tool integrations (Bonus A):
    1. SMTP Email delivery with fallback simulation.
    2. WhatsApp Click-to-Chat direct link builder.
    3. Webhook export dispatcher.
    """

    @classmethod
    def test_smtp_connection(cls):
        """Tests live SMTP server credentials."""
        if not Config.SMTP_USER or not Config.SMTP_PASSWORD:
            return {
                "success": False,
                "status": "unconfigured",
                "message": "SMTP credentials not configured in .env (SMTP_USER / SMTP_PASSWORD). Running in Draft/Simulation mode."
            }
        try:
            server = smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=5)
            server.starttls()
            server.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
            server.quit()
            return {
                "success": True,
                "status": "connected",
                "message": f"Successfully connected to SMTP server ({Config.SMTP_HOST}:{Config.SMTP_PORT})."
            }
        except Exception as e:
            return {
                "success": False,
                "status": "error",
                "message": f"SMTP connection failed: {str(e)}"
            }

    @classmethod
    def send_payment_reminder_email(cls, recipient_email, subject, body_text):
        """Sends an actual email via SMTP, or records simulated delivery."""
        if not Config.SMTP_USER or not Config.SMTP_PASSWORD:
            # Fallback simulation
            return {
                "success": True,
                "mode": "simulated",
                "message": f"[Simulation Mode] Email reminder prepared for {recipient_email}. Configure SMTP_USER in .env for live transmission."
            }

        try:
            msg = MIMEMultipart()
            msg['From'] = f"{Config.SMTP_FROM_NAME} <{Config.SMTP_USER}>"
            msg['To'] = recipient_email
            msg['Subject'] = subject
            msg.attach(MIMEText(body_text, 'plain'))

            server = smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=10)
            server.starttls()
            server.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
            server.send_message(msg)
            server.quit()

            return {
                "success": True,
                "mode": "live",
                "message": f"Email successfully sent to {recipient_email} via SMTP."
            }
        except Exception as e:
            return {
                "success": False,
                "mode": "live_failed",
                "error": str(e)
            }

    @classmethod
    def generate_whatsapp_link(cls, phone_number, message_text):
        """
        Creates a direct WhatsApp Click-to-Chat URL.
        Works across WhatsApp Web, Windows Desktop, and mobile devices without requiring paid API keys!
        """
        clean_phone = "".join(filter(str.isdigit, str(phone_number or "")))
        if len(clean_phone) == 10:
            clean_phone = "91" + clean_phone # Add Indian country code by default

        encoded_text = urllib.parse.quote(message_text)
        if clean_phone:
            url = f"https://wa.me/{clean_phone}?text={encoded_text}"
        else:
            url = f"https://wa.me/?text={encoded_text}"

        return {
            "url": url,
            "target_phone": clean_phone or "Not Specified",
            "encoded_message": encoded_text
        }

integrations = IntegrationManager()
