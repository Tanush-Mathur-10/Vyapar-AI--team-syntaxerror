// ====================================================================
// VyaparAI - RAG Chat Interface Script (Version 2.0 with AI Thinking)
// AVINYA 2K26 - SIIC, IIT Kanpur
// ====================================================================

document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const messagesBox = document.getElementById('chat-messages');
    const voiceBtn = document.getElementById('btn-voice-mic');

    if (!chatForm || !chatInput || !messagesBox) return;

    // Mic click handler
    if (voiceBtn) {
        voiceBtn.addEventListener('click', () => {
            const currentLang = localStorage.getItem('vyaparai_lang') || 'en';
            voiceEngine.toggleListening(currentLang);
        });
    }

    // Quick prompt buttons
    document.querySelectorAll('.quick-prompt-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const promptText = btn.getAttribute('data-prompt');
            if (promptText) {
                chatInput.value = promptText;
                submitQuestion(promptText);
            }
        });
    });

    // Auto-submit if q parameter passed in URL
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get('q');
    if (queryParam) {
        chatInput.value = queryParam;
        submitQuestion(queryParam);
    }

    // Form submit
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = chatInput.value.trim();
        if (text) {
            submitQuestion(text);
        }
    });

    async function submitQuestion(question) {
        const lang = localStorage.getItem('vyaparai_lang') || 'en';
        chatInput.value = '';
        
        // Append user bubble
        appendMessage('user', question);

        // Append thinking placeholder
        const loadingId = 'ai-loading-' + Date.now();
        appendLoading(loadingId);

        try {
            const resp = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question, language: lang })
            });

            const data = await resp.json();
            removeLoading(loadingId);

            if (data.success) {
                appendMessage('ai', data.answer, data.citations, lang, data.thinking);
            } else {
                appendMessage('ai', 'Error generating response: ' + (data.error || 'Server error'), [], lang, null);
            }
        } catch (err) {
            removeLoading(loadingId);
            appendMessage('ai', 'Network error connecting to VyaparAI backend.', [], lang, null);
        }
    }

    function appendMessage(sender, text, citations = [], lang = 'en', thinking = null) {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${sender}`;

        if (sender === 'user') {
            bubble.textContent = text;
        } else {
            // 1. Thinking Process Block (Requirement 3)
            let thinkingHtml = '';
            if (thinking && thinking.trim().length > 0) {
                const safeThinking = thinking.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                thinkingHtml = `
                <div class="thinking-box">
                    <div class="thinking-header" onclick="const c = this.nextElementSibling; c.style.display = (c.style.display === 'none' ? 'block' : 'none');">
                        <span>🧠 AI Thinking & Invoice Audit Process</span>
                        <span style="font-size: 0.75rem; color: #2563eb; font-weight: 600;">View Analysis Steps ▼</span>
                    </div>
                    <div class="thinking-content" style="display: block;">
                        ${safeThinking}
                    </div>
                </div>`;
            }

            // 2. Format basic markdown
            let formatted = text
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/^### (.*$)/gim, '<h4 style="margin: 0.5rem 0; color: #0f2c59; font-size: 1.05rem;">$1</h4>')
                .replace(/^#### (.*$)/gim, '<h5 style="margin: 0.4rem 0; color: #1e293b; font-size: 0.95rem;">$1</h5>')
                .replace(/\n/g, '<br/>');

            // 3. Grounded Citations
            let citationsHtml = '';
            if (citations && citations.length > 0) {
                citationsHtml = `
                <div style="margin-top: 1rem; border-top: 1px solid #e2e8f0; padding-top: 0.75rem;">
                    <div style="font-size: 0.75rem; font-weight: 800; color: #475569; text-transform: uppercase; margin-bottom: 0.35rem; display: flex; align-items: center; gap: 0.35rem;">
                        <span>📑 Grounded Document Citations</span>
                        <span class="badge badge-success" style="font-size: 0.65rem;">Verified</span>
                    </div>
                    ${citations.map(c => `
                        <div class="citation-card">
                            <div style="display: flex; justify-content: space-between; font-weight: 700; color: #1e40af;">
                                <span>📄 ${c.filename} (Page ${c.page_number})</span>
                                <span style="color: #059669; font-size: 0.75rem;">Match: ${(c.relevance_score * 100).toFixed(0)}%</span>
                            </div>
                            <div style="margin-top: 3px; color: #475569; font-style: italic; font-size: 0.78rem;">"${c.excerpt}"</div>
                        </div>
                    `).join('')}
                </div>`;
            }

            // 4. Audio Readout
            const audioBtnHtml = `
            <div style="display: flex; justify-content: flex-end; margin-top: 0.65rem;">
                <button class="btn btn-secondary btn-sm" onclick="voiceEngine.speakText(${JSON.stringify(text).replace(/"/g, '&quot;')}, '${lang}')" title="Listen to AI Answer">
                    🔊 Listen
                </button>
            </div>`;

            bubble.innerHTML = thinkingHtml + formatted + citationsHtml + audioBtnHtml;
        }

        messagesBox.appendChild(bubble);
        messagesBox.scrollTop = messagesBox.scrollHeight;
    }

    function appendLoading(id) {
        const load = document.createElement('div');
        load.id = id;
        load.className = 'chat-bubble ai';
        load.innerHTML = '<em>🧠 Gemini is analyzing invoices, auditing bank receipts, and retrieving RAG evidence...</em>';
        messagesBox.appendChild(load);
        messagesBox.scrollTop = messagesBox.scrollHeight;
    }

    function removeLoading(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }
});
