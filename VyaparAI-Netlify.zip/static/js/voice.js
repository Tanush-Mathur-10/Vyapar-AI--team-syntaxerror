// ====================================================================
// VyaparAI - Conversational Voice Agent Engine (Version 3.0 Robust)
// AVINYA 2K26 - SIIC, IIT Kanpur
// ====================================================================

class VoiceEngine {
    constructor() {
        this.recognition = null;
        this.isListening = false;
        this.synth = window.speechSynthesis || null;
        this.voices = [];
        this.silenceTimer = null;
        this.currentTranscript = "";
        this.isAgentMode = false;
        this.resumeTimer = null;

        this.initVoices();
        this.initRecognition();
    }

    initVoices() {
        if (!this.synth) return;
        this.populateVoices();
        if (typeof this.synth.onvoiceschanged !== 'undefined') {
            this.synth.onvoiceschanged = () => this.populateVoices();
        }
    }

    populateVoices() {
        if (!this.synth) return;
        this.voices = this.synth.getVoices() || [];
    }

    getBestVoice(langCode) {
        if (!this.voices || this.voices.length === 0) {
            this.populateVoices();
        }
        if (!this.voices || this.voices.length === 0) return null;

        const langPrefixMap = {
            'en': ['en-IN', 'en-GB', 'en-US', 'en'],
            'hi': ['hi-IN', 'hi', 'hin'],
            'bn': ['bn-IN', 'bn', 'ben'],
            'mr': ['mr-IN', 'mr', 'mar'],
            'ta': ['ta-IN', 'ta', 'tam'],
            'te': ['te-IN', 'te', 'tel'],
            'gu': ['gu-IN', 'gu', 'guj'],
            'kn': ['kn-IN', 'kn', 'kan']
        };

        const prefixes = langPrefixMap[langCode] || ['en-IN', 'en'];

        for (const pref of prefixes) {
            const found = this.voices.find(v => v.lang.toLowerCase().includes(pref.toLowerCase()) || v.name.toLowerCase().includes(pref.toLowerCase()));
            if (found) return found;
        }

        // Fallback to any Indian voice or English voice
        const fallback = this.voices.find(v => v.lang.includes('IN') || v.lang.startsWith('en')) || this.voices[0];
        return fallback;
    }

    initRecognition() {
        const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRec) {
            console.warn("Speech recognition not supported in this browser.");
            return;
        }

        try {
            this.recognition = new SpeechRec();
            this.recognition.continuous = false;
            this.recognition.interimResults = true;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateUI(true);
                const statusEl = document.getElementById('voiceAgentStatus');
                if (statusEl) statusEl.textContent = 'Listening... Speak now';
            };

            this.recognition.onresult = (event) => {
                let interimTranscript = '';
                let finalTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    } else {
                        interimTranscript += event.results[i][0].transcript;
                    }
                }

                const activeText = (finalTranscript || interimTranscript).trim();
                this.currentTranscript = activeText;

                // Update input on Chat page
                const inputEl = document.getElementById('chat-input');
                if (inputEl) inputEl.value = activeText;

                // Update Voice Agent Modal Transcript
                const agentTranscriptEl = document.getElementById('voiceAgentTranscript');
                if (agentTranscriptEl) {
                    agentTranscriptEl.innerHTML = `<strong>You:</strong> "${activeText}"`;
                }

                // If in conversational mode, detect pause and submit query
                if (this.isAgentMode && activeText.length > 3) {
                    clearTimeout(this.silenceTimer);
                    this.silenceTimer = setTimeout(() => {
                        this.stopListening();
                        this.submitAgentQuery(activeText);
                    }, 1600);
                }
            };

            this.recognition.onerror = (event) => {
                console.warn("Speech Recognition Error:", event.error);
                this.isListening = false;
                this.updateUI(false);
                const statusEl = document.getElementById('voiceAgentStatus');
                if (statusEl) {
                    if (event.error === 'not-allowed') {
                        statusEl.textContent = 'Microphone permission denied. Please allow microphone in browser.';
                    } else if (event.error === 'no-speech') {
                        statusEl.textContent = 'No speech detected. Tap orb and speak clearly.';
                    } else {
                        statusEl.textContent = `Mic ready. Tap orb to speak (${event.error})`;
                    }
                }
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateUI(false);
            };
        } catch (e) {
            console.error("Failed to initialize speech recognition:", e);
        }
    }

    startAgentListening(langCode = 'en') {
        this.isAgentMode = true;
        this.stopSpeaking();
        this.currentTranscript = "";

        const statusEl = document.getElementById('voiceAgentStatus');
        if (statusEl) statusEl.textContent = 'Starting microphone... Speak naturally';

        const transcriptEl = document.getElementById('voiceAgentTranscript');
        if (transcriptEl) transcriptEl.innerHTML = '<em>Listening... (e.g. "Which bills are overdue this week?", "Sharma ji ka kitna paisa baki hai?")</em>';

        this.startListening(langCode);
    }

    startListening(langCode = 'en') {
        if (!this.recognition) {
            showToast("Speech recognition is not supported in this browser. Please use Chrome or Edge.", "warning");
            return;
        }

        const localeMap = {
            'en': 'en-IN',
            'hi': 'hi-IN',
            'bn': 'bn-IN',
            'mr': 'mr-IN',
            'ta': 'ta-IN',
            'te': 'te-IN',
            'gu': 'gu-IN',
            'kn': 'kn-IN'
        };

        this.recognition.lang = localeMap[langCode] || 'en-IN';

        try {
            if (this.isListening) {
                this.recognition.stop();
            }
            this.recognition.start();
        } catch (e) {
            console.warn("Recognition start issue:", e);
        }
    }

    stopListening() {
        if (this.recognition && this.isListening) {
            try { this.recognition.stop(); } catch (e) {}
        }
        this.isListening = false;
        this.updateUI(false);
    }

    toggleListening(langCode = 'en') {
        if (this.isListening) {
            this.stopListening();
        } else {
            this.startListening(langCode);
        }
    }

    updateUI(listening) {
        const micBtn = document.getElementById('btn-voice-mic');
        if (micBtn) {
            if (listening) {
                micBtn.classList.add('active');
                micBtn.title = "Listening... Click to stop";
            } else {
                micBtn.classList.remove('active');
                micBtn.title = "Click to speak";
            }
        }

        const orb = document.getElementById('voiceAgentOrb');
        if (orb) {
            if (listening) {
                orb.style.boxShadow = "0 0 50px rgba(37, 99, 235, 0.9)";
                orb.style.transform = "scale(1.1)";
            } else {
                orb.style.boxShadow = "0 0 30px rgba(37, 99, 235, 0.5)";
                orb.style.transform = "scale(1)";
            }
        }
    }

    async submitAgentQuery(query) {
        const statusEl = document.getElementById('voiceAgentStatus');
        if (statusEl) statusEl.textContent = '🧠 Agent thinking & verifying database ledgers...';

        const lang = localStorage.getItem('vyaparai_lang') || 'en';

        try {
            const resp = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question: query, language: lang })
            });
            const data = await resp.json();

            if (data.success) {
                if (statusEl) statusEl.textContent = '🔊 Agent Speaking response...';
                
                const agentBox = document.getElementById('voiceAgentTranscript');
                if (agentBox) {
                    agentBox.innerHTML = `
                        <div style="margin-bottom: 0.5rem; color: #1e40af;"><strong>You:</strong> "${query}"</div>
                        <div style="color: #0f172a; line-height: 1.5; max-height: 140px; overflow-y: auto;">
                            <strong>VyaparAI:</strong> ${data.answer.replace(/\n/g, '<br/>')}
                        </div>
                    `;
                }

                // Automatically speak the answer aloud!
                this.speakText(data.answer, lang, () => {
                    if (statusEl) statusEl.textContent = 'Tap orb or speak again to continue';
                });
            } else {
                if (statusEl) statusEl.textContent = 'Error: ' + (data.error || 'Server issue');
            }
        } catch (err) {
            if (statusEl) statusEl.textContent = 'Connection error reaching VyaparAI.';
        }
    }

    speakText(text, langCode = 'en', onComplete = null) {
        if (!this.synth) {
            console.warn("SpeechSynthesis not available.");
            return;
        }

        // Cancel previous speech
        this.synth.cancel();
        clearInterval(this.resumeTimer);

        if (!text || text.trim().length === 0) return;

        // Clean markdown symbols for natural speech
        let clean = text
            .replace(/[*#_`]/g, '')
            .replace(/₹/g, 'Rupees ')
            .replace(/\n+/g, '. ')
            .trim();

        // Limit spoken length to first 60 words for snappy, responsive speech
        const words = clean.split(' ');
        const spokenExcerpt = words.slice(0, 60).join(' ') + (words.length > 60 ? '. Please check your screen for full details.' : '');

        const utterance = new SpeechSynthesisUtterance(spokenExcerpt);
        const voice = this.getBestVoice(langCode);
        if (voice) {
            utterance.voice = voice;
            utterance.lang = voice.lang;
        } else {
            utterance.lang = langCode === 'hi' ? 'hi-IN' : 'en-IN';
        }

        utterance.rate = 1.0;
        utterance.pitch = 1.0;

        utterance.onend = () => {
            clearInterval(this.resumeTimer);
            if (onComplete) onComplete();
        };

        utterance.onerror = (e) => {
            clearInterval(this.resumeTimer);
            console.warn("Speech synthesis error/interrupted:", e);
            if (onComplete) onComplete();
        };

        // Chromium keep-alive resume timer (prevents silent pause bug)
        this.resumeTimer = setInterval(() => {
            if (this.synth.speaking) {
                this.synth.pause();
                this.synth.resume();
            } else {
                clearInterval(this.resumeTimer);
            }
        }, 12000);

        this.synth.speak(utterance);
    }

    testAudio(langCode = 'en') {
        const testPhrases = {
            'en': 'Hello! VyaparAI voice assistant is active and working properly.',
            'hi': 'नमस्ते! व्यापार एआई वॉइस असिस्टेंट सक्रिय है और काम कर रहा है।',
            'bn': 'নমস্কার! ব্যাপার এআই ভয়েস সহকারী সক্রিয় আছে।',
            'mr': 'नमस्कार! व्यापार एआय व्हॉइस असिस्टंट सक्रिय आहे.',
            'ta': 'வணக்கம்! வியாபார் ஏஐ குரல் உதவியாளர் செயலில் உள்ளது.',
            'te': 'నమస్కారం! వ్యాపార ఏఐ వాయిస్ అసిస్టెంట్ పనిచేస్తోంది.',
            'gu': 'નમસ્તે! વ્યાપાર એઆઈ વૉઇસ સહાયક સક્રિય છે.',
            'kn': 'ನಮಸ್ಕಾರ! ವ್ಯಾಪಾರ್ ಎಐ ಧ್ವನಿ ಸಹಾಯಕ ಸಕ್ರಿಯವಾಗಿದೆ.'
        };

        const phrase = testPhrases[langCode] || testPhrases['en'];
        this.speakText(phrase, langCode, () => {
            showToast("Audio test playback completed!", "success");
        });
    }

    stopSpeaking() {
        if (this.synth) {
            this.synth.cancel();
            clearInterval(this.resumeTimer);
        }
    }
}

const voiceEngine = new VoiceEngine();
