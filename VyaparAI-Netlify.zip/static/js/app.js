// ====================================================================
// VyaparAI - Core Application Script (Version 3.0 Full Multilingual)
// AVINYA 2K26 - SIIC, IIT Kanpur
// ====================================================================

// Comprehensive Multilingual UI Dictionary (8 Indian Languages)
const UI_TRANSLATIONS = {
    'en': {
        'overview': 'Overview',
        'data_explorer': 'Data Explorer',
        'integrations': 'Integrations',
        'workflows': 'Workflows',
        'projects': 'Projects',
        'team': 'Team',
        'settings': 'Settings',
        'copilot': 'AI Copilot',
        'talk_agent': '🎙️ Voice Agent',
        'new_project': 'New Project',
        'search_placeholder': 'Search anything... (invoices, customers, bills)',
        'greeting_title': 'Good morning, Aayush 👋',
        'greeting_sub': "Here's what's happening with your workspace today.",
        'total_projects': 'Total Projects',
        'active_integrations': 'Active Integrations',
        'data_sources': 'Data Sources',
        'team_members': 'Team Members',
        'trend_last_week_up12': '↑ 12% from last week',
        'trend_last_week_up2': '↑ 2% from last week',
        'trend_last_week_up20': '↑ 20% from last week',
        'trend_last_week_neutral': '↑ 0% from last week',
        'platform_analytics': 'Platform Analytics',
        'last_7_days': 'Last 7 days',
        'total_data_processed': 'Total Data Processed',
        'successful_runs': 'Successful Runs',
        'avg_response_time': 'Avg. Response Time',
        'rag_inspector_title': '🧠 RAG Engine & Agent Pipeline Inspector',
        'rag_inspector_sub': 'Understand in real-time what RAG retrieves from your documents and how the AI agent calculates actions.',
        'step_1_title': '1. 📄 Chunk & Vectorize',
        'step_2_title': '2. 🔍 Vector Similarity',
        'step_3_title': '3. 🧮 SQL Fact Truth',
        'step_4_title': '4. 🧠 Agent Execution',
        'run_live_trace': '⚡ Run Live Trace',
        'recent_projects': 'Recent Projects',
        'view_all': 'View all →',
        'th_name': 'Name',
        'th_status': 'Status',
        'th_last_modified': 'Last Modified',
        'th_owner': 'Owner',
        'quick_actions': 'Quick Actions',
        'explore_data': 'Explore Data',
        'explore_data_sub': 'Visualize and analyze your data',
        'connect_integration': 'Connect Integration',
        'connect_integration_sub': 'Link your favorite tools',
        'create_workflow': 'Create Workflow',
        'create_workflow_sub': 'Automate your processes',
        'new_project_sub': 'Start a new project',
        'recent_activity': 'Recent Activity',
        'critical_alert': '⚠️ CRITICAL OVERDUE ALERT'
    },
    'hi': {
        'overview': 'अवलोकन (Overview)',
        'data_explorer': 'दस्तावेज़ समीक्षा (Data)',
        'integrations': 'कनेक्टेड टूल्स (Integrations)',
        'workflows': 'भुगतान स्मरण (Workflows)',
        'projects': 'चालान व बिल (Projects)',
        'team': 'ग्राहक व खाता (Team)',
        'settings': 'प्रोफ़ाइल सेटिंग्स',
        'copilot': 'व्यापार AI कोपायलट',
        'talk_agent': '🎙️ बोलकर बात करें',
        'new_project': '+ नया चालान',
        'search_placeholder': 'कुछ भी खोजें... (बिल नंबर, ग्राहक नाम, राशि)',
        'greeting_title': 'शुभ प्रभात, आयुष 👋',
        'greeting_sub': 'आज आपके व्यापार और बहीखातों की स्थिति यहाँ है।',
        'total_projects': 'कुल चालान (Projects)',
        'active_integrations': 'सक्रिय टूल्स (UPI/बैंक)',
        'data_sources': 'अपलोड किए गए बिल',
        'team_members': 'सक्रिय ग्राहक पार्टियां',
        'trend_last_week_up12': '↑ पिछले सप्ताह से 12% अधिक',
        'trend_last_week_up2': '↑ पिछले सप्ताह से 2% अधिक',
        'trend_last_week_up20': '↑ पिछले सप्ताह से 20% अधिक',
        'trend_last_week_neutral': '↑ कोई बदलाव नहीं',
        'platform_analytics': 'नकदी प्रवाह विश्लेषण (Analytics)',
        'last_7_days': 'पिछले 7 दिन',
        'total_data_processed': 'कुल जारी बिल राशि',
        'successful_runs': 'वसूली दर (सफलता)',
        'avg_response_time': 'औसत भुगतान अवधि',
        'rag_inspector_title': '🧠 RAG इंजन और AI एजेंट पाइपलाइन विश्लेषक',
        'rag_inspector_sub': 'लाइव देखें कि RAG ने फाइलों से क्या निकाला और एजेंट ने क्या निर्णय लिया।',
        'step_1_title': '1. 📄 चंक और 768-D वेक्टर',
        'step_2_title': '2. 🔍 वेक्टर कोसाइन समानता',
        'step_3_title': '3. 🧮 SQL डेटाबेस सत्य (सटीक गणित)',
        'step_4_title': '4. 🧠 एजेंट निर्णय व तकादा',
        'run_live_trace': '⚡ लाइव ट्रेस चलाएं',
        'recent_projects': 'हालिया चालान और बिल',
        'view_all': 'सभी देखें →',
        'th_name': 'बिल / पार्टी का नाम',
        'th_status': 'स्थिति',
        'th_last_modified': 'नियत तिथि',
        'th_owner': 'ग्राहक पार्टी',
        'quick_actions': 'त्वरित कार्य (Quick Actions)',
        'explore_data': 'डेटा विश्लेषण व AI',
        'explore_data_sub': 'बहीखाते और बिलों का विश्लेषण करें',
        'connect_integration': 'टूल्स कनेक्ट करें',
        'connect_integration_sub': 'WhatsApp और ईमेल जोड़ें',
        'create_workflow': 'तकादा भेजें (रिमाइंडर)',
        'create_workflow_sub': 'समय पर वसूली स्वचालित करें',
        'new_project_sub': 'नया जीएसटी बिल जारी करें',
        'recent_activity': 'हालिया गतिविधियां',
        'critical_alert': '⚠️ अतिदेय भुगतान चेतावनी'
    },
    'bn': {
        'overview': 'ওভারভিউ',
        'data_explorer': 'নথিপত্র ও ডেটা',
        'integrations': 'টুলস ও সংযোগ',
        'workflows': 'পেমেন্ট রিমাইন্ডার',
        'projects': 'চালান ও বিল',
        'team': 'গ্রাহক ও খাতা',
        'settings': 'সেটিংস',
        'copilot': 'এআই কোপাইলট',
        'talk_agent': '🎙️ কথা বলুন',
        'new_project': '+ নতুন চালান',
        'search_placeholder': 'বিল বা গ্রাহকের নাম দিয়ে খুঁজুন...',
        'greeting_title': 'শুভ সকাল, আয়ুষ 👋',
        'greeting_sub': 'আজ আপনার ব্যবসার বর্তমান পরিস্থিতি এখানে রয়েছে।',
        'total_projects': 'মোট চালান',
        'active_integrations': 'সক্রিয় ইন্টিগ্রেশন',
        'data_sources': 'নথিপত্র উৎস',
        'team_members': 'গ্রাহক সদস্য',
        'trend_last_week_up12': '↑ গত সপ্তাহ থেকে ১২% বেশি',
        'trend_last_week_up2': '↑ গত সপ্তাহ থেকে ২% বেশি',
        'trend_last_week_up20': '↑ গত সপ্তাহ থেকে ২০% বেশি',
        'trend_last_week_neutral': '↑ কোনো পরিবর্তন নেই',
        'platform_analytics': 'ক্যাশফ্লো অ্যানালিটিক্স',
        'last_7_days': 'গত ৭ দিন',
        'total_data_processed': 'মোট বিলের পরিমাণ',
        'successful_runs': 'টাকা আদায়ের হার',
        'avg_response_time': 'গড় বকেয়া সময়',
        'rag_inspector_title': '🧠 RAG ইঞ্জিন ও এজেন্ট পরিদর্শক',
        'rag_inspector_sub': 'রিয়েল-টাইমে দেখুন RAG কী খুঁজে পেয়েছে এবং এজেন্ট কীভাবে কাজ করছে।',
        'step_1_title': '১. 📄 খণ্ড ও ভেক্টরাইজ',
        'step_2_title': '২. 🔍 ভেক্টর সাদৃশ্য অনুসন্ধান',
        'step_3_title': '৩. 🧮 SQL গণিত সত্য',
        'step_4_title': '৪. 🧠 এজেন্ট সিদ্ধান্ত গ্রহণ',
        'run_live_trace': '⚡ লাইভ ট্রেস চালান',
        'recent_projects': 'সাম্প্রতিক চালানসমূহ',
        'view_all': 'সব দেখুন →',
        'th_name': 'নাম',
        'th_status': 'স্থিতি',
        'th_last_modified': 'নির্দিষ্ট তারিখ',
        'th_owner': 'গ্রাহক',
        'quick_actions': 'দ্রুত পদক্ষেপ',
        'explore_data': 'ডেটা অন্বেষণ করুন',
        'explore_data_sub': 'আপনার আর্থিক ডেটা পরীক্ষা করুন',
        'connect_integration': 'টুলস সংযুক্ত করুন',
        'connect_integration_sub': 'হোয়াটসঅ্যাপ ও ইমেল লিঙ্ক করুন',
        'create_workflow': 'ওয়ার্কফ্লো তৈরি করুন',
        'create_workflow_sub': 'পেমেন্ট তাগাদা স্বয়ংক্রিয় করুন',
        'new_project_sub': 'নতুন বিল তৈরি করুন',
        'recent_activity': 'সাম্প্রতিক কার্যকলাপ',
        'critical_alert': '⚠️ জরুরি বকেয়া সতর্কতা'
    },
    'mr': {
        'overview': 'आढावा (Overview)',
        'data_explorer': 'दस्तऐवज समीक्षा',
        'integrations': 'जोडलेली साधने',
        'workflows': 'पेमेंट स्मरणपत्रे',
        'projects': 'चलन व बिले',
        'team': 'ग्राहक आणि खाती',
        'settings': 'सेटिंग्ज',
        'copilot': 'व्यापार AI कोपायलट',
        'talk_agent': '🎙️ बोलून संवाद साधा',
        'new_project': '+ नवीन चलन',
        'search_placeholder': 'काहीही शोधा... (बिल, ग्राहक, चलन)',
        'greeting_title': 'शुभ सकाळ, आयुष 👋',
        'greeting_sub': 'आज आपल्या व्यवसायाची स्थिती येथे आहे.',
        'total_projects': 'एकूण चलन',
        'active_integrations': 'सक्रिय जोडण्या',
        'data_sources': 'डेटा स्रोत',
        'team_members': 'ग्राहक संघ',
        'trend_last_week_up12': '↑ मागील आठवड्यापेक्षा १२% जास्त',
        'trend_last_week_up2': '↑ मागील आठवड्यापेक्षा २% जास्त',
        'trend_last_week_up20': '↑ मागील आठवड्यापेक्षा २०% जास्त',
        'trend_last_week_neutral': '↑ बदल नाही',
        'platform_analytics': 'प्लॅटफॉर्म विश्लेषण',
        'last_7_days': 'मागील ७ दिवस',
        'total_data_processed': 'एकूण विक्री रक्कम',
        'successful_runs': 'वसुली दर',
        'avg_response_time': 'सरासरी विलंब दिवस',
        'rag_inspector_title': '🧠 RAG इंजिन आणि एजंट पाइपलाइन',
        'rag_inspector_sub': 'RAG ने काय शोधले आणि एजंटने काय सल्ला दिला ते थेट पहा.',
        'step_1_title': '१. 📄 तुकडे व व्हेक्टर',
        'step_2_title': '२. 🔍 व्हेक्टर साम्य शोध',
        'step_3_title': '३. 🧮 SQL सत्य गणित',
        'step_4_title': '४. 🧠 एजंट अंमलबजावणी',
        'run_live_trace': '⚡ थेट ट्रेस चालवा',
        'recent_projects': 'अलीकडील बिले',
        'view_all': 'सर्व पहा →',
        'th_name': 'नाव',
        'th_status': 'स्थिती',
        'th_last_modified': 'देय तारीख',
        'th_owner': 'ग्राहक',
        'quick_actions': 'त्वरित कृती',
        'explore_data': 'डेटा एक्सप्लोर करा',
        'explore_data_sub': 'आपल्या खात्यांचे विश्लेषण करा',
        'connect_integration': 'साधने जोडा',
        'connect_integration_sub': 'WhatsApp आणि ईमेल जोडा',
        'create_workflow': 'वर्कफ्लो तयार करा',
        'create_workflow_sub': 'थकीत वसुली स्वयंचलित करा',
        'new_project_sub': 'नवीन जीएसटी बिल सुरू करा',
        'recent_activity': 'अलीकडील क्रियाकलाप',
        'critical_alert': '⚠️ गंभीर थकीत इशारा'
    },
    'ta': {
        'overview': 'மேலோட்டம்',
        'data_explorer': 'ஆவணங்கள் ஆய்வு',
        'integrations': 'இணைப்புகள்',
        'workflows': 'கட்டண நினைவூட்டல்கள்',
        'projects': 'விலைப்பட்டியல்கள்',
        'team': 'வாடிக்கையாளர்கள்',
        'settings': 'அமைப்புகள்',
        'copilot': 'ஏஐ கோபைலட்',
        'talk_agent': '🎙️ பேசிப் பாருங்கள்',
        'new_project': '+ புதிய பில்',
        'search_placeholder': 'எதையும் தேடுங்கள்...',
        'greeting_title': 'காலை வணக்கம், ஆயுஷ் 👋',
        'greeting_sub': 'இன்று உங்கள் வணிகத்தில் என்ன நடக்கிறது என்பது இங்கே.',
        'total_projects': 'மொத்த விலைப்பட்டியல்கள்',
        'active_integrations': 'செயலில் உள்ள இணைப்புகள்',
        'data_sources': 'தரவு மூலங்கள்',
        'team_members': 'வாடிக்கையாளர் குழு',
        'trend_last_week_up12': '↑ கடந்த வாரத்தை விட 12% அதிகம்',
        'trend_last_week_up2': '↑ கடந்த வாரத்தை விட 2% அதிகம்',
        'trend_last_week_up20': '↑ கடந்த வாரத்தை விட 20% அதிகம்',
        'trend_last_week_neutral': '↑ மாற்றமில்லை',
        'platform_analytics': 'தள பகுப்பாய்வு',
        'last_7_days': 'கடந்த 7 நாட்கள்',
        'total_data_processed': 'மொத்த விற்பனைத் தொகை',
        'successful_runs': 'வசூல் வெற்றி விகிதம்',
        'avg_response_time': 'சராசரி நிலுவை நாட்கள்',
        'rag_inspector_title': '🧠 RAG இயந்திரம் மற்றும் முகவர் ஆய்வாளர்',
        'rag_inspector_sub': 'RAG ஆவணங்களிலிருந்து என்ன மீட்டெடுத்தது என்பதை நிகழ்நேரத்தில் புரிந்து கொள்ளுங்கள்.',
        'step_1_title': '1. 📄 துண்டு மற்றும் வெக்டரைஸ்',
        'step_2_title': '2. 🔍 வெக்டர் ஒற்றுமை',
        'step_3_title': '3. 🧮 SQL துல்லியமான உண்மை',
        'step_4_title': '4. 🧠 முகவர் முடிவெடுத்தல்',
        'run_live_trace': '⚡ நேரடி சோதனை',
        'recent_projects': 'சமீபத்திய திட்டங்கள்',
        'view_all': 'அனைத்தையும் காண்க →',
        'th_name': 'பெயர்',
        'th_status': 'நிலை',
        'th_last_modified': 'செலுத்த வேண்டிய தேதி',
        'th_owner': 'வாடிக்கையாளர்',
        'quick_actions': 'விரைவான செயல்கள்',
        'explore_data': 'தரவை ஆராயுங்கள்',
        'explore_data_sub': 'உங்கள் வணிகத் தரவை ஆய்வு செய்யுங்கள்',
        'connect_integration': 'இணைப்பை இணைக்கவும்',
        'connect_integration_sub': 'வாட்ஸ்அப் மற்றும் மின்னஞ்சலை இணைக்கவும்',
        'create_workflow': 'பணிப்பாய்வு உருவாக்கவும்',
        'create_workflow_sub': 'கட்டண வசூலை தானியங்குபடுத்துங்கள்',
        'new_project_sub': 'புதிய பில் தொடங்கவும்',
        'recent_activity': 'சமீபத்திய செயல்பாடு',
        'critical_alert': '⚠️ நிலுவைத் தொகை எச்சரிக்கை'
    },
    'te': {
        'overview': 'అవలోకనం',
        'data_explorer': 'డాక్యుమెంట్ డేటా',
        'integrations': 'ఇంటిగ్రేషన్లు',
        'workflows': 'చెల్లింపు రిమైండర్లు',
        'projects': 'ఇన్వాయిస్‌లు & బిల్లులు',
        'team': 'కస్టమర్లు & ఖాతా',
        'settings': 'సెట్టింగ్‌లు',
        'copilot': 'వ్యాపార AI కోపైలట్',
        'talk_agent': '🎙️ మాట్లాడండి',
        'new_project': '+ కొత్త ఇన్వాయిస్',
        'search_placeholder': 'ఏదైనా శోధించండి...',
        'greeting_title': 'శుభోదయం, ఆయుష్ 👋',
        'greeting_sub': 'ఈ రోజు మీ వ్యాపారంలో ఏమి జరుగుతుందో ఇక్కడ చూడండి.',
        'total_projects': 'మొత్తం ఇన్వాయిస్‌లు',
        'active_integrations': 'యాక్టివ్ ఇంటిగ్రేషన్లు',
        'data_sources': 'డాక్యుమెంట్ మూలాలు',
        'team_members': 'కస్టమర్ బృందం',
        'trend_last_week_up12': '↑ గత వారం కంటే 12% ఎక్కువ',
        'trend_last_week_up2': '↑ గత వారం కంటే 2% ఎక్కువ',
        'trend_last_week_up20': '↑ గత వారం కంటే 20% ఎక్కువ',
        'trend_last_week_neutral': '↑ మార్పు లేదు',
        'platform_analytics': 'ప్లాట్‌ఫారమ్ విశ్లేషణ',
        'last_7_days': 'గత 7 రోజులు',
        'total_data_processed': 'మొత్తం విక్రయ మొత్తం',
        'successful_runs': 'వసూళ్ల విజయ రేటు',
        'avg_response_time': 'సగటు బకాయి కాలం',
        'rag_inspector_title': '🧠 RAG ఇంజిన్ & ఏజెంట్ పైప్‌లైన్',
        'rag_inspector_sub': 'RAG మీ ఫైళ్ళ నుండి ఏమి సేకరించిందో నిజ సమయంలో చూడండి.',
        'step_1_title': '1. 📄 ముక్కలు & వెక్టరైజ్',
        'step_2_title': '2. 🔍 వెక్టర్ సారూప్యత',
        'step_3_title': '3. 🧮 SQL గణిత సత్యం',
        'step_4_title': '4. 🧠 ఏజెంట్ కార్యాచరణ',
        'run_live_trace': '⚡ లైవ్ ట్రేస్ రన్ చేయండి',
        'recent_projects': 'ఇటీవలి ఇన్వాయిస్‌లు',
        'view_all': 'అన్నీ చూడండి →',
        'th_name': 'పేరు',
        'th_status': 'స్థితి',
        'th_last_modified': 'గడువు తేదీ',
        'th_owner': 'కస్టమర్',
        'quick_actions': 'శీఘ్ర చర్యలు',
        'explore_data': 'డేటాను అన్వేషించండి',
        'explore_data_sub': 'మీ వ్యాపార డేటాను విశ్లేషించండి',
        'connect_integration': 'టూల్స్ కనెక్ట్ చేయండి',
        'connect_integration_sub': 'WhatsApp మరియు ఈమెయిల్ జోడించండి',
        'create_workflow': 'వర్క్‌ఫ్లో సృష్టించండి',
        'create_workflow_sub': 'చెల్లింపుల వసూళ్లను ఆటోమేట్ చేయండి',
        'new_project_sub': 'కొత్త బిల్లు ప్రారంభించండి',
        'recent_activity': 'ఇటీవలి కార్యాచరణ',
        'critical_alert': '⚠️ క్లిష్టమైన బకాయిల హెచ్చరిక'
    },
    'gu': {
        'overview': 'વિહંગાવલોકન',
        'data_explorer': 'દસ્તાવેજો સમીક્ષા',
        'integrations': 'જોડાણો (Tools)',
        'workflows': 'ચુકવણી રીમાઇન્ડર',
        'projects': 'ચલણ અને બિલ',
        'team': 'ગ્રાહકો અને ખાતા',
        'settings': 'સેટિંગ્સ',
        'copilot': 'વ્યાપાર AI કોપાયલટ',
        'talk_agent': '🎙️ બોલીને વાત કરો',
        'new_project': '+ નવું બિલ',
        'search_placeholder': 'કંઈપણ શોધો (બિલ, ગ્રાહક)...',
        'greeting_title': 'શુભ સવાર, આયુષ 👋',
        'greeting_sub': 'આજે તમારા વ્યવસાયની સ્થિતિ અહીં છે.',
        'total_projects': 'કુલ બિલ (Projects)',
        'active_integrations': 'સક્રિય ટૂલ્સ',
        'data_sources': 'દસ્તાવેજ સ્ત્રોત',
        'team_members': 'ગ્રાહક સભ્યો',
        'trend_last_week_up12': '↑ ગયા અઠવાડિયા કરતાં 12% વધુ',
        'trend_last_week_up2': '↑ ગયા અઠવાડિયા કરતાં 2% વધુ',
        'trend_last_week_up20': '↑ ગયા અઠવાડિયા કરતાં 20% વધુ',
        'trend_last_week_neutral': '↑ કોઈ ફેરફાર નથી',
        'platform_analytics': 'પ્લેટફોર્મ એનાલિટિક્સ',
        'last_7_days': 'છેલ્લા 7 દિવસ',
        'total_data_processed': 'કુલ વેચાણ રકમ',
        'successful_runs': 'વસૂલાત દર',
        'avg_response_time': 'સરેરાશ બાકી દિવસો',
        'rag_inspector_title': '🧠 RAG એન્જિન અને એજન્ટ પાઇપલાઇન',
        'rag_inspector_sub': 'RAG એ દસ્તાવેજોમાંથી શું મેળવ્યું તે લાઈવ જુઓ.',
        'step_1_title': '1. 📄 ટુકડા અને વેક્ટર',
        'step_2_title': '2. 🔍 વેક્ટર સમાનતા',
        'step_3_title': '3. 🧮 SQL ડેટાબેઝ સત્ય',
        'step_4_title': '4. 🧠 એજન્ટ નિર્ણય',
        'run_live_trace': '⚡ લાઈવ ટ્રેસ ચલાવો',
        'recent_projects': 'તાજેતરના બિલ',
        'view_all': 'બધા જુઓ →',
        'th_name': 'નામ',
        'th_status': 'સ્થિતિ',
        'th_last_modified': 'છેલ્લી તારીખ',
        'th_owner': 'ગ્રાહક',
        'quick_actions': 'ઝડપી ક્રિયાઓ',
        'explore_data': 'ડેટા અન્વેષણ કરો',
        'explore_data_sub': 'તમારા ડેટાનું વિશ્લેષણ કરો',
        'connect_integration': 'ટૂલ્સ કનેક્ટ કરો',
        'connect_integration_sub': 'WhatsApp અને ઈમેલ જોડો',
        'create_workflow': 'વર્કફ્લો બનાવો',
        'create_workflow_sub': 'ચુકવણી ફોલો-અપ સ્વચાલિત કરો',
        'new_project_sub': 'નવું જીએસટી બિલ બનાવો',
        'recent_activity': 'તાજેતરની પ્રવૃત્તિ',
        'critical_alert': '⚠️ અતિ બાકી રકમની ચેતવણી'
    },
    'kn': {
        'overview': 'ಅವಲೋಕನ (Overview)',
        'data_explorer': 'ದಾಖಲೆಗಳ ಪರಿಶೀಲನೆ',
        'integrations': 'ಸಂಯೋಜನೆಗಳು',
        'workflows': 'ಪಾವತಿ ಜ್ಞಾಪನೆಗಳು',
        'projects': 'ಇನ್‌ವಾಯ್ಸ್‌ಗಳು & ಬಿಲ್ಲುಗಳು',
        'team': 'ಗ್ರಾಹಕರು & ಖಾತೆ',
        'settings': 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
        'copilot': 'ವ್ಯಾಪಾರ್ AI ಕೋಪೈಲಟ್',
        'talk_agent': '🎙️ ಮಾತನಾಡಿ',
        'new_project': '+ ಹೊಸ ಬಿಲ್',
        'search_placeholder': 'ಏನನ್ನಾದರೂ ಹುಡುಕಿ...',
        'greeting_title': 'ಶುಭೋದಯ, ಆಯುಷ್ 👋',
        'greeting_sub': 'ಇಂದು ನಿಮ್ಮ ವ್ಯವಹಾರದ ಸ್ಥಿತಿಗತಿ ಇಲ್ಲಿದೆ.',
        'total_projects': 'ಒಟ್ಟು ಇನ್‌ವಾಯ್ಸ್‌ಗಳು',
        'active_integrations': 'ಸಕ್ರಿಯ ಸಂಯೋಜನೆಗಳು',
        'data_sources': 'ಡೇಟಾ ಮೂಲಗಳು',
        'team_members': 'ಗ್ರಾಹಕ ಸದಸ್ಯರು',
        'trend_last_week_up12': '↑ ಕಳೆದ ವಾರಕ್ಕಿಂತ 12% ಹೆಚ್ಚು',
        'trend_last_week_up2': '↑ ಕಳೆದ ವಾರಕ್ಕಿಂತ 2% ಹೆಚ್ಚು',
        'trend_last_week_up20': '↑ ಕಳೆದ ವಾರಕ್ಕಿಂತ 20% ಹೆಚ್ಚು',
        'trend_last_week_neutral': '↑ ಬದಲಾವಣೆ ಇಲ್ಲ',
        'platform_analytics': 'ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ವಿಶ್ಲೇಷಣೆ',
        'last_7_days': 'ಕಳೆದ 7 ದಿನಗಳು',
        'total_data_processed': 'ಒಟ್ಟು ಮಾರಾಟ ಮೊತ್ತ',
        'successful_runs': 'ವಸೂಲಾತಿ ದರ',
        'avg_response_time': 'ಸರಾಸರಿ ಬಾಕಿ ದಿನಗಳು',
        'rag_inspector_title': '🧠 RAG ಎಂಜಿನ್ ಮತ್ತು ಏಜೆಂಟ್ ಪೈಪ್‌ಲೈನ್',
        'rag_inspector_sub': 'RAG ಏನು ಹುಡುಕಿದೆ ಮತ್ತು ಏಜೆಂಟ್ ಹೇಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಲೈವ್ ಆಗಿ ನೋಡಿ.',
        'step_1_title': '1. 📄 ತುಂಡು & ವೆಕ್ಟರ್',
        'step_2_title': '2. 🔍 ವೆಕ್ಟರ್ ಹೋಲಿಕೆ',
        'step_3_title': '3. 🧮 SQL ಸತ್ಯ ಗಣಿತ',
        'step_4_title': '4. 🧠 ಏಜೆಂಟ್ ನಿರ್ಧಾರ',
        'run_live_trace': '⚡ ಲೈವ್ ಟ್ರೇಸ್ ರನ್ ಮಾಡಿ',
        'recent_projects': 'ಇತ್ತೀಚಿನ ಬಿಲ್ಲುಗಳು',
        'view_all': 'ಎಲ್ಲವನ್ನೂ ವೀಕ್ಷಿಸಿ →',
        'th_name': 'ಹೆಸರು',
        'th_status': 'ಸ್ಥಿತಿ',
        'th_last_modified': 'ಕೊನೆಯ ದಿನಾಂಕ',
        'th_owner': 'ಗ್ರಾಹಕರು',
        'quick_actions': 'ತ್ವರಿತ ಕ್ರಿಯೆಗಳು',
        'explore_data': 'ಡೇಟಾವನ್ನು ಅನ್ವೇಷಿಸಿ',
        'explore_data_sub': 'ನಿಮ್ಮ ವ್ಯವಹಾರ ಡೇಟಾ ವಿಶ್ಲೇಷಿಸಿ',
        'connect_integration': 'ಟೂಲ್ಸ್ ಸಂಪರ್ಕಿಸಿ',
        'connect_integration_sub': 'WhatsApp ಮತ್ತು ಇಮೇಲ್ ಲಿಂಕ್ ಮಾಡಿ',
        'create_workflow': 'ವರ್ಕ್‌ಫ್ಲೋ ರಚಿಸಿ',
        'create_workflow_sub': 'ಪಾವತಿ ವಸೂಲಿ ಸ್ವಯಂಚಾಲಿತಗೊಳಿಸಿ',
        'new_project_sub': 'ಹೊಸ ಬಿಲ್ ಪ್ರಾರಂಭಿಸಿ',
        'recent_activity': 'ಇತ್ತೀಚಿನ ಚಟುವಟಿಕೆ',
        'critical_alert': '⚠️ ನಿರ್ಣಾಯಕ ಬಾಕಿ ಎಚ್ಚರಿಕೆ'
    }
};

// Toast Notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.position = 'fixed';
    toast.style.bottom = '24px';
    toast.style.right = '24px';
    toast.style.zIndex = '9999';
    toast.style.padding = '12px 20px';
    toast.style.borderRadius = '12px';
    toast.style.fontSize = '0.88rem';
    toast.style.fontWeight = '700';
    toast.style.boxShadow = '0 10px 25px rgba(0,0,0,0.18)';
    toast.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
    toast.style.transform = 'translateY(20px)';
    toast.style.opacity = '0';

    if (type === 'success') {
        toast.style.background = '#059669';
        toast.style.color = '#ffffff';
    } else if (type === 'error' || type === 'danger') {
        toast.style.background = '#dc2626';
        toast.style.color = '#ffffff';
    } else if (type === 'warning') {
        toast.style.background = '#d97706';
        toast.style.color = '#ffffff';
    } else {
        toast.style.background = '#1e3a8a';
        toast.style.color = '#ffffff';
    }

    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';
    });

    setTimeout(() => {
        toast.style.transform = 'translateY(20px)';
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 350);
    }, 3200);
}

// Modal Helpers
function openModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) el.classList.add('active');
}

function closeModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) el.classList.remove('active');
}

// Mode Switcher (Demo vs Live) with Confirmation
let pendingMode = null;

function requestModeSwitch(targetMode) {
    pendingMode = targetMode;
    const isTargetDemo = targetMode === 'demo';
    
    document.getElementById('modeModalTitle').textContent = isTargetDemo 
        ? 'Switch to Demo Mode (Sample Data)?' 
        : 'Switch to Live Business Mode (My Real Business)?';
        
    document.getElementById('modeModalDesc').innerHTML = isTargetDemo
        ? '<strong>Demo Mode</strong> loads realistic Kanpur MSME sample invoices, customers, and payment balances for live presentations and testing.'
        : '<strong>Live Mode</strong> opens your real, dedicated business workspace where you can upload actual invoices, track genuine payments, and manage real customers.';
        
    openModal('modeConfirmModal');
}

async function confirmModeSwitch() {
    if (!pendingMode) return;
    const btn = document.getElementById('btnConfirmModeSwitch');
    btn.disabled = true;
    btn.textContent = 'Switching Workspace...';

    try {
        const resp = await fetch('/api/mode/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mode: pendingMode })
        });
        const data = await resp.json();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => window.location.reload(), 800);
        } else {
            showToast('Failed to switch mode: ' + data.error, 'error');
            btn.disabled = false;
            btn.textContent = 'Confirm Switch';
        }
    } catch (err) {
        showToast('Network error switching mode', 'error');
        btn.disabled = false;
        btn.textContent = 'Confirm Switch';
    }
}

// Language Switcher Helper (Translates Full Page!)
function setAppLanguage(lang) {
    localStorage.setItem('vyaparai_lang', lang);
    const select = document.getElementById('lang-selector');
    if (select) select.value = lang;
    
    // Apply UI translations to labelled elements across entire page
    applyUITranslations(lang);
    
    const langNames = {
        'en': 'English', 'hi': 'हिन्दी', 'bn': 'বাংলা', 'mr': 'मराठी',
        'ta': 'தமிழ்', 'te': 'తెలుగు', 'gu': 'ગુજરાતી', 'kn': 'ಕನ್ನಡ'
    };
    showToast(`Language set to ${langNames[lang] || lang}`, 'info');
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: { language: lang } }));
}

function applyUITranslations(lang) {
    const dict = UI_TRANSLATIONS[lang] || UI_TRANSLATIONS['en'];
    
    // Translate all elements with data-i18n attribute
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
            el.textContent = dict[key];
        }
    });

    // Translate search bar placeholder
    const searchInput = document.getElementById('topSearchInput');
    if (searchInput && dict['search_placeholder']) {
        searchInput.placeholder = dict['search_placeholder'];
    }
}

// App Guide Modal Handler
function openAppGuide() {
    openModal('appGuideModal');
}

// Conversational Voice Agent Modal Handler
function openVoiceAgentModal() {
    openModal('voiceAgentModal');
    if (typeof voiceEngine !== 'undefined') {
        const currentLang = localStorage.getItem('vyaparai_lang') || 'en';
        voiceEngine.startAgentListening(currentLang);
    }
}

function closeVoiceAgentModal() {
    if (typeof voiceEngine !== 'undefined') {
        voiceEngine.stopListening();
        voiceEngine.stopSpeaking();
    }
    closeModal('voiceAgentModal');
}

// Global Keyboard and Backdrop Listeners
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
    }
    // Ctrl + K shortcut
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        const searchInput = document.getElementById('topSearchInput');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
});

function handleSearchKey(event) {
    if (event.key === 'Enter') {
        const query = event.target.value.trim();
        if (query) {
            window.location.href = `/chat?q=${encodeURIComponent(query)}`;
        }
    }
}

document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const savedLang = localStorage.getItem('vyaparai_lang') || 'en';
    const select = document.getElementById('lang-selector');
    if (select) {
        select.value = savedLang;
        select.addEventListener('change', (e) => setAppLanguage(e.target.value));
    }
    applyUITranslations(savedLang);

    // Dynamic current date display in topbar
    const dateEl = document.getElementById('currentDateDisplay');
    const greetingDate = document.getElementById('greetingDate');
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    const dateStr = new Date().toLocaleDateString('en-US', options);
    if (dateEl) dateEl.textContent = dateStr;
    if (greetingDate) greetingDate.textContent = dateStr;
});
