"""
VyaparAI - Database Initialization Script
AVINYA 2K26, SIIC, IIT Kanpur
Run this script to initialize MySQL (or SQLite fallback) tables and seed data.
"""
import sys
from core.db import db
from config import Config

def main():
    print("=" * 60)
    print(" VyaparAI Database Setup - SIIC IIT Kanpur")
    print("=" * 60)
    print(f"Configured Database Type : {Config.DB_TYPE.upper()}")
    if Config.DB_TYPE == 'mysql':
        print(f"Target MySQL Host        : {Config.DB_HOST}:{Config.DB_PORT}")
        print(f"Target Database Name     : {Config.DB_NAME}")
        print(f"Target User              : {Config.DB_USER}")
    else:
        print(f"Target SQLite File       : {Config.SQLITE_PATH}")

    print("\nRunning database table initialization...")
    success, message = db.init_database()
    
    if success:
        status = db.get_status_info()
        print(f"SUCCESS: {message}")
        print(f"Active Engine: {status['engine'].upper()}")
        if status['is_fallback']:
            print(f"Notice: {status['fallback_reason']}")
        
        biz = db.get_active_business()
        print(f"\nDefault Business Profile Active:")
        print(f" - Name     : {biz['name']}")
        print(f" - City     : {biz['city']}, {biz.get('state', '')}")
        print(f" - Currency : {biz['currency']}")
        print(f" - GSTIN    : {biz.get('gstin', 'N/A')}")
        print(f" - Terms    : {biz.get('payment_terms', 'Net 30')}")
        print("\nDatabase is ready for VyaparAI!")
    else:
        print(f"FAILED: {message}")
        sys.exit(1)

if __name__ == "__main__":
    main()
