import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent

# Load environment variables from .env file
load_dotenv(BASE_DIR / ".env")

class Config:
    BASE_DIR = BASE_DIR
    # Flask settings
    SECRET_KEY = os.getenv("SECRET_KEY", "vyaparai-siic-iitk-demo-secret-key-2026")
    DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")
    PORT = int(os.getenv("PORT", "5000"))

    # Database settings
    DB_TYPE = os.getenv("DB_TYPE", "sqlite").lower() # 'mysql' or 'sqlite'
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_NAME = os.getenv("DB_NAME", "vyaparai_db")
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    SQLITE_PATH = BASE_DIR / "vyaparai.db"

    # AI & LLM settings
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "models/text-embedding-004")

    # Document upload directories
    UPLOAD_FOLDER = BASE_DIR / "uploads"
    GENERATED_FOLDER = BASE_DIR / "generated"
    DEMO_DATA_FOLDER = BASE_DIR / "demo_data"
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit
    ALLOWED_EXTENSIONS = {"pdf", "csv", "png", "jpg", "jpeg"}

    # Demo / Reference Date (useful for reproducible demo judging)
    DEMO_REFERENCE_DATE = os.getenv("DEMO_REFERENCE_DATE", "2026-10-15")

    # SMTP Settings (Bonus A)
    SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM_NAME = os.getenv("SMTP_FROM_NAME", "VyaparAI Billing Desk")

    # WhatsApp API
    WHATSAPP_API_KEY = os.getenv("WHATSAPP_API_KEY", "")
    WHATSAPP_BUSINESS_PHONE = os.getenv("WHATSAPP_BUSINESS_PHONE", "")

# Ensure directories exist
for path in [Config.UPLOAD_FOLDER, Config.GENERATED_FOLDER, Config.DEMO_DATA_FOLDER]:
    path.mkdir(parents=True, exist_ok=True)
