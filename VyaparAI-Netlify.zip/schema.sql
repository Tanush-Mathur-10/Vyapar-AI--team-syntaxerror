-- ====================================================================
-- VyaparAI Database Schema (MySQL 8.0+)
-- AVINYA 2K26 - SIIC, IIT Kanpur
-- AI Copilot for Indian MSMEs
-- ====================================================================

-- 1. Business Profiles
CREATE TABLE IF NOT EXISTS businesses (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    business_type VARCHAR(100) DEFAULT 'General Trade',
    city VARCHAR(100) DEFAULT 'Kanpur',
    state VARCHAR(100) DEFAULT 'Uttar Pradesh',
    currency VARCHAR(10) DEFAULT 'INR',
    gstin VARCHAR(20) DEFAULT NULL,
    payment_terms VARCHAR(100) DEFAULT 'Net 30',
    priorities TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Documents (Uploaded Files)
CREATE TABLE IF NOT EXISTS documents (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    saved_filename VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size_bytes INT NOT NULL,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    extraction_status VARCHAR(50) DEFAULT 'pending', -- pending, extracted, review_needed, failed
    raw_text LONGTEXT DEFAULT NULL,
    page_count INT DEFAULT 1,
    notes TEXT DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

-- 3. Document Chunks & Vector Metadata (RAG Storage)
CREATE TABLE IF NOT EXISTS document_chunks (
    id VARCHAR(36) PRIMARY KEY,
    document_id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    chunk_index INT NOT NULL,
    chunk_text TEXT NOT NULL,
    page_number INT DEFAULT 1,
    doc_type VARCHAR(50) DEFAULT 'invoice',
    embedding_json LONGTEXT DEFAULT NULL, -- Stores vector embeddings as JSON array of floats
    metadata_json TEXT DEFAULT NULL,       -- Stores extracted entity tags, invoice_no, party_name
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

-- 4. Customers & Suppliers Directory
CREATE TABLE IF NOT EXISTS parties (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    contact_person VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    gstin VARCHAR(20) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    party_type VARCHAR(20) DEFAULT 'customer', -- customer, supplier, both
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);

-- 5. Invoices & Bills
CREATE TABLE IF NOT EXISTS invoices (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    document_id VARCHAR(36) DEFAULT NULL,
    party_id VARCHAR(36) DEFAULT NULL,
    party_name VARCHAR(255) NOT NULL,
    invoice_number VARCHAR(100) NOT NULL,
    invoice_type VARCHAR(20) DEFAULT 'sale', -- sale (invoice to customer), purchase (bill from supplier)
    invoice_date DATE NOT NULL,
    due_date DATE DEFAULT NULL,
    subtotal DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    discount_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    balance_due DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    payment_status VARCHAR(30) DEFAULT 'unpaid', -- paid, partially_paid, unpaid, overdue, cancelled
    is_uncertain BOOLEAN DEFAULT FALSE,
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL,
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_invoice_num ON invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_due_date ON invoices(due_date);
CREATE INDEX IF NOT EXISTS idx_status ON invoices(payment_status);

-- 6. Invoice Line Items
CREATE TABLE IF NOT EXISTS invoice_items (
    id VARCHAR(36) PRIMARY KEY,
    invoice_id VARCHAR(36) NOT NULL,
    description VARCHAR(255) NOT NULL,
    hsn_code VARCHAR(50) DEFAULT NULL,
    quantity DECIMAL(10, 2) DEFAULT 1.00,
    unit_price DECIMAL(12, 2) DEFAULT 0.00,
    tax_rate DECIMAL(5, 2) DEFAULT 18.00,
    tax_amount DECIMAL(12, 2) DEFAULT 0.00,
    total_amount DECIMAL(12, 2) DEFAULT 0.00,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- 7. Payment Transactions
CREATE TABLE IF NOT EXISTS payments (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    invoice_id VARCHAR(36) NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'UPI', -- UPI, NEFT, RTGS, IMPS, Cheque, Cash
    reference_number VARCHAR(100) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- 8. AI Recommendations & Action Plan
CREATE TABLE IF NOT EXISTS recommendations (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    invoice_id VARCHAR(36) DEFAULT NULL,
    document_id VARCHAR(36) DEFAULT NULL,
    finding TEXT NOT NULL,
    verified_facts TEXT NOT NULL,
    supporting_evidence TEXT NOT NULL,
    recommended_action TEXT NOT NULL,
    expected_impact VARCHAR(255) NOT NULL,
    priority VARCHAR(20) DEFAULT 'high', -- high, medium, low
    status VARCHAR(30) DEFAULT 'pending', -- pending, actioned, dismissed
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL
);

-- 9. Generated Payment Reminders
CREATE TABLE IF NOT EXISTS payment_reminders (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    invoice_id VARCHAR(36) NOT NULL,
    party_id VARCHAR(36) DEFAULT NULL,
    recipient_name VARCHAR(255) NOT NULL,
    channel VARCHAR(50) DEFAULT 'whatsapp', -- whatsapp, email, sms
    tone VARCHAR(50) DEFAULT 'polite',       -- polite, firm, formal, urgent
    language VARCHAR(10) DEFAULT 'en',       -- en, hi
    reminder_text TEXT NOT NULL,
    status VARCHAR(30) DEFAULT 'drafted',   -- drafted, copied, shared
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE SET NULL
);

-- 10. Integrations & Tool Settings
CREATE TABLE IF NOT EXISTS integrations (
    id VARCHAR(36) PRIMARY KEY,
    business_id VARCHAR(36) NOT NULL,
    service_name VARCHAR(100) NOT NULL, -- smtp_email, whatsapp_api, webhook
    is_enabled BOOLEAN DEFAULT FALSE,
    config_json TEXT DEFAULT NULL,
    last_tested TIMESTAMP NULL DEFAULT NULL,
    last_status VARCHAR(50) DEFAULT 'not_configured',
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
);
