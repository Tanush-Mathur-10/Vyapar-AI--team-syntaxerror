import os
import sys
import uuid
import json
import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
from werkzeug.utils import secure_filename

from config import Config
from core.db import db
from core.document_parser import DocumentParser
from core.rag_engine import rag_engine
from core.financial_engine import financial_engine
from core.ai_copilot import ai_copilot
from core.pdf_generator import pdf_generator
from core.integrations import integrations

app = Flask(__name__)
app.config.from_object(Config)

# Ensure database tables exist at startup
with app.app_context():
    db.init_database()

# -----------------------------------------------------------------------------
# Template Filters & Context Processors
# -----------------------------------------------------------------------------
@app.context_processor
def inject_globals():
    biz = db.get_active_business()
    db_status = db.get_status_info()
    current_mode = db.get_current_mode()
    return {
        "active_business": biz,
        "db_status": db_status,
        "current_mode": current_mode,
        "current_year": datetime.datetime.now().year,
        "demo_ref_date": Config.DEMO_REFERENCE_DATE
    }

@app.template_filter('currency')
def format_currency(value):
    try:
        val = float(value or 0.0)
        return f"₹{val:,.2f}"
    except (ValueError, TypeError):
        return f"₹0.00"

@app.template_filter('date_format')
def format_date(value):
    if not value:
        return "N/A"
    return str(value)[:10]

# -----------------------------------------------------------------------------
# Web Page Views
# -----------------------------------------------------------------------------
@app.route('/')
def dashboard_view():
    """Action Center Dashboard with KPIs, overdue items, charts, and AI action cards."""
    biz = db.get_active_business()
    biz_id = biz["id"]
    metrics = financial_engine.get_dashboard_metrics(biz_id)
    overdue_invoices = financial_engine.get_overdue_invoices(biz_id)
    recommendations = ai_copilot.generate_action_plan(biz_id)
    
    # Recent documents
    recent_docs = db.execute_query(
        "SELECT * FROM documents WHERE business_id = %s ORDER BY upload_date DESC LIMIT 5",
        (biz_id,)
    )
    return render_template(
        'dashboard.html',
        metrics=metrics,
        overdue_invoices=overdue_invoices,
        recommendations=recommendations,
        recent_docs=recent_docs
    )

@app.route('/profile')
def profile_view():
    """Business Profile configuration page."""
    biz = db.get_active_business()
    return render_template('profile.html', business=biz)

@app.route('/documents')
def documents_view():
    """Document upload, structured review, and chunk inspection."""
    biz = db.get_active_business()
    docs = db.execute_query(
        "SELECT * FROM documents WHERE business_id = %s ORDER BY upload_date DESC",
        (biz["id"],)
    )
    return render_template('documents.html', documents=docs)

@app.route('/invoices')
def invoices_view():
    """Invoices and Bills directory with create invoice form."""
    biz = db.get_active_business()
    invoices = db.execute_query(
        """SELECT i.*, d.original_filename as document_name 
           FROM invoices i 
           LEFT JOIN documents d ON i.document_id = d.id 
           WHERE i.business_id = %s 
           ORDER BY i.invoice_date DESC""",
        (biz["id"],)
    )
    parties = db.execute_query("SELECT * FROM parties WHERE business_id = %s", (biz["id"],))
    return render_template('invoices.html', invoices=invoices, parties=parties)

@app.route('/customers')
def customers_view():
    """Customer payment aging, overdue totals, and reliability ratings."""
    biz = db.get_active_business()
    customers = financial_engine.get_customer_aging(biz["id"])
    return render_template('customers.html', customers=customers)

@app.route('/chat')
def chat_view():
    """Ask VyaparAI & Voice Copilot (Bilingual English/Hindi)."""
    return render_template('chat.html')

@app.route('/reminders')
def reminders_view():
    """Payment Reminder Generator for overdue invoices."""
    biz = db.get_active_business()
    overdue_invoices = financial_engine.get_overdue_invoices(biz["id"])
    reminders = db.execute_query(
        "SELECT * FROM payment_reminders WHERE business_id = %s ORDER BY created_at DESC LIMIT 10",
        (biz["id"],)
    )
    return render_template('reminders.html', overdue_invoices=overdue_invoices, reminders=reminders)

@app.route('/integrations')
def integrations_view():
    """External tool integrations (SMTP, WhatsApp, Webhooks)."""
    return render_template('integrations.html')

# -----------------------------------------------------------------------------
# REST API Endpoints
# -----------------------------------------------------------------------------
@app.route('/api/status', methods=['GET'])
def api_status():
    """System health and active database/AI engines."""
    db_info = db.get_status_info()
    return jsonify({
        "status": "healthy",
        "app": "VyaparAI",
        "event": "AVINYA 2K26, SIIC IIT Kanpur",
        "database": db_info,
        "gemini_ai_configured": bool(Config.GEMINI_API_KEY),
        "demo_reference_date": Config.DEMO_REFERENCE_DATE
    })

@app.route('/api/profile', methods=['POST'])
def api_update_profile():
    """Updates active business profile."""
    biz = db.get_active_business()
    data = request.json or request.form
    sql = """
    UPDATE businesses
    SET name = %s, business_type = %s, city = %s, state = %s,
        currency = %s, gstin = %s, payment_terms = %s, priorities = %s
    WHERE id = %s
    """
    db.execute_commit(sql, (
        data.get('name', biz['name']),
        data.get('business_type', biz['business_type']),
        data.get('city', biz['city']),
        data.get('state', biz.get('state', 'Uttar Pradesh')),
        data.get('currency', biz.get('currency', 'INR')),
        data.get('gstin', biz.get('gstin')),
        data.get('payment_terms', biz.get('payment_terms', 'Net 30')),
        data.get('priorities', biz.get('priorities')),
        biz['id']
    ))
    return jsonify({"success": True, "message": "Business profile updated successfully."})

@app.route('/api/documents/upload', methods=['POST'])
def api_upload_document():
    """
    Uploads and processes document (PDF, CSV, Image).
    Extracts text, identifies invoice entities, stores chunks, and creates RAG vectors.
    """
    biz = db.get_active_business()
    biz_id = biz["id"]

    if 'file' not in request.files:
        return jsonify({"success": False, "error": "No file uploaded."}), 400

    file = request.files['file']
    if not file.filename:
        return jsonify({"success": False, "error": "No file selected."}), 400

    ext = Path(file.filename).suffix.lower().replace(".", "")
    if ext not in Config.ALLOWED_EXTENSIONS:
        return jsonify({"success": False, "error": f"Unsupported format (.{ext}). Allowed: PDF, CSV, PNG, JPG."}), 400

    doc_id = f"doc_{uuid.uuid4().hex[:8]}"
    saved_filename = f"{doc_id}_{secure_filename(file.filename)}"
    file_path = Config.UPLOAD_FOLDER / saved_filename
    file.save(str(file_path))

    file_size = os.path.getsize(str(file_path))

    # Parse and extract
    parse_result = DocumentParser.parse_document(file_path, file.filename)
    if not parse_result.get("success"):
        return jsonify({"success": False, "error": parse_result.get("error")}), 500

    # Save to documents table
    extracted_fields = parse_result.get("extracted_fields", {})
    status = "review_needed" if (isinstance(extracted_fields, dict) and extracted_fields.get("is_uncertain")) else "extracted"
    
    db.execute_commit("""
    INSERT INTO documents (id, business_id, original_filename, saved_filename, file_type, file_size_bytes, extraction_status, raw_text, page_count)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        doc_id, biz_id, file.filename, saved_filename, ext, file_size, status,
        parse_result.get("full_text"), parse_result.get("page_count", 1)
    ))

    # Index into RAG chunks
    parse_result["original_filename"] = file.filename
    chunk_count = rag_engine.chunk_document(doc_id, biz_id, parse_result)

    # If single invoice extracted from PDF/Image, create unconfirmed or confirmed invoice record
    if isinstance(extracted_fields, dict) and extracted_fields.get("invoice_number"):
        party_name = extracted_fields.get("party_name") or "Unassigned Party"
        # Ensure party
        party = db.execute_one("SELECT id FROM parties WHERE business_id = %s AND name = %s", (biz_id, party_name))
        if party:
            party_id = party["id"]
        else:
            party_id = f"pty_{uuid.uuid4().hex[:8]}"
            db.execute_commit("""
            INSERT INTO parties (id, business_id, name, party_type)
            VALUES (%s, %s, %s, 'customer')
            """, (party_id, biz_id, party_name))

        inv_id = f"inv_{uuid.uuid4().hex[:8]}"
        db.execute_commit("""
        INSERT INTO invoices (id, business_id, document_id, party_id, party_name, invoice_number, invoice_type, invoice_date, due_date, subtotal, tax_amount, discount_amount, total_amount, amount_paid, balance_due, payment_status, is_uncertain, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0.00, %s, %s, %s, %s, %s, %s)
        """, (
            inv_id, biz_id, doc_id, party_id, party_name,
            extracted_fields.get("invoice_number"),
            "sale" if extracted_fields.get("party_type") == "customer" else "purchase",
            extracted_fields.get("invoice_date") or datetime.date.today().isoformat(),
            extracted_fields.get("due_date"),
            extracted_fields.get("subtotal", 0.0),
            extracted_fields.get("tax_amount", 0.0),
            extracted_fields.get("total_amount", 0.0),
            extracted_fields.get("amount_paid", 0.0),
            extracted_fields.get("balance_due", 0.0),
            extracted_fields.get("payment_status", "unpaid"),
            1 if extracted_fields.get("is_uncertain") else 0,
            f"Extracted from {file.filename}"
        ))

    return jsonify({
        "success": True,
        "document_id": doc_id,
        "filename": file.filename,
        "chunks_indexed": chunk_count,
        "extracted_fields": extracted_fields,
        "status": status
    })

@app.route('/api/documents/<doc_id>')
def api_get_document(doc_id):
    """Retrieves document detail, raw text, and all associated RAG chunks."""
    doc = db.execute_one("SELECT * FROM documents WHERE id = %s", (doc_id,))
    if not doc:
        return jsonify({"success": False, "error": "Document not found."}), 404
    chunks = db.execute_query("SELECT id, chunk_index, chunk_text, page_number FROM document_chunks WHERE document_id = %s ORDER BY chunk_index ASC", (doc_id,))
    invoices = db.execute_query("SELECT * FROM invoices WHERE document_id = %s", (doc_id,))
    return jsonify({
        "success": True,
        "document": doc,
        "chunks": chunks,
        "invoices": invoices
    })

@app.route('/api/documents/<doc_id>/review', methods=['POST'])
def api_review_document(doc_id):
    """Allows user to correct extracted fields for an uncertain document."""
    data = request.json
    inv_id = data.get("invoice_id")
    biz = db.get_active_business()
    
    total = float(data.get("total_amount", 0.0))
    paid = float(data.get("amount_paid", 0.0))
    bal = max(0.0, total - paid)

    if inv_id:
        sql = """
        UPDATE invoices
        SET invoice_number = %s, party_name = %s, invoice_date = %s, due_date = %s,
            total_amount = %s, amount_paid = %s, balance_due = %s, is_uncertain = 0,
            payment_status = %s
        WHERE id = %s
        """
        status = "paid" if bal <= 0 else ("partially_paid" if paid > 0 else "unpaid")
        db.execute_commit(sql, (
            data.get("invoice_number"), data.get("party_name"),
            data.get("invoice_date"), data.get("due_date"),
            total, paid, bal, status, inv_id
        ))
    
    # Mark document as verified
    db.execute_commit("UPDATE documents SET extraction_status = 'extracted' WHERE id = %s", (doc_id,))
    return jsonify({"success": True, "message": "Document and invoice fields updated and verified."})

@app.route('/api/invoices/create', methods=['POST'])
def api_create_invoice():
    """
    Creates a new invoice in VyaparAI.
    Calculates totals in Python, saves to database, creates RAG chunk, and generates PDF.
    """
    biz = db.get_active_business()
    biz_id = biz["id"]
    data = request.json or request.form

    inv_num = data.get("invoice_number") or f"INV-{uuid.uuid4().hex[:6].upper()}"
    party_name = data.get("party_name", "Walk-in Customer").strip()
    inv_date = data.get("invoice_date") or datetime.date.today().isoformat()
    due_date = data.get("due_date") or None

    # Line items
    raw_items = data.get("items", [])
    if isinstance(raw_items, str):
        try:
            raw_items = json.loads(raw_items)
        except Exception:
            raw_items = []

    if not raw_items:
        # Default single item from form
        desc = data.get("item_description", "Electrical Components")
        qty = float(data.get("quantity", 1))
        rate = float(data.get("unit_price", 0))
        tax_rate = float(data.get("tax_rate", 18))
        item_sub = qty * rate
        item_tax = (item_sub * tax_rate) / 100.0
        raw_items = [{
            "description": desc,
            "quantity": qty,
            "unit_price": rate,
            "tax_rate": tax_rate,
            "tax_amount": item_tax,
            "total_amount": item_sub + item_tax
        }]

    # Python Financial Calculation
    subtotal = sum(float(it.get("quantity", 1)) * float(it.get("unit_price", 0)) for it in raw_items)
    tax_amount = sum(float(it.get("tax_amount", 0)) for it in raw_items)
    total_amount = subtotal + tax_amount
    amount_paid = float(data.get("amount_paid", 0.0))
    balance_due = max(0.0, total_amount - amount_paid)

    # Status
    ref_date = financial_engine.get_reference_date()
    if balance_due <= 0 and total_amount > 0:
        payment_status = "paid"
    elif due_date and datetime.date.fromisoformat(due_date[:10]) < ref_date and balance_due > 0:
        payment_status = "overdue"
    elif amount_paid > 0:
        payment_status = "partially_paid"
    else:
        payment_status = "unpaid"

    # Ensure Party exists
    party = db.execute_one("SELECT id FROM parties WHERE business_id = %s AND name = %s", (biz_id, party_name))
    if party:
        party_id = party["id"]
    else:
        party_id = f"pty_{uuid.uuid4().hex[:8]}"
        db.execute_commit("""
        INSERT INTO parties (id, business_id, name, party_type)
        VALUES (%s, %s, %s, 'customer')
        """, (party_id, biz_id, party_name))

    # Save Invoice
    inv_id = f"inv_{uuid.uuid4().hex[:8]}"
    db.execute_commit("""
    INSERT INTO invoices (id, business_id, party_id, party_name, invoice_number, invoice_type, invoice_date, due_date, subtotal, tax_amount, total_amount, amount_paid, balance_due, payment_status, notes)
    VALUES (%s, %s, %s, %s, %s, 'sale', %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        inv_id, biz_id, party_id, party_name, inv_num, inv_date, due_date,
        subtotal, tax_amount, total_amount, amount_paid, balance_due, payment_status,
        data.get("notes", "Created in VyaparAI Billing Desk")
    ))

    # Save Line Items
    for it in raw_items:
        it_id = f"itm_{uuid.uuid4().hex[:8]}"
        db.execute_commit("""
        INSERT INTO invoice_items (id, invoice_id, description, quantity, unit_price, tax_rate, tax_amount, total_amount)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            it_id, inv_id, it.get("description"), it.get("quantity"),
            it.get("unit_price"), it.get("tax_rate", 18),
            it.get("tax_amount", 0), it.get("total_amount", 0)
        ))

    # Generate PDF Invoice
    pdf_path = Config.GENERATED_FOLDER / f"invoice_{inv_num}.pdf"
    inv_data = {
        "invoice_number": inv_num,
        "party_name": party_name,
        "invoice_date": inv_date,
        "due_date": due_date,
        "subtotal": subtotal,
        "tax_amount": tax_amount,
        "total_amount": total_amount,
        "amount_paid": amount_paid,
        "balance_due": balance_due,
        "payment_status": payment_status
    }
    pdf_generator.generate_invoice_pdf(inv_data, raw_items, pdf_path)

    # Register in RAG chunks
    chunk_text = f"Tax Invoice {inv_num} issued to {party_name}. Subtotal: ₹{subtotal:,.2f}, GST: ₹{tax_amount:,.2f}, Total: ₹{total_amount:,.2f}, Paid: ₹{amount_paid:,.2f}, Balance: ₹{balance_due:,.2f}. Due Date: {due_date}. Status: {payment_status}."
    dummy_doc_id = f"doc_gen_{uuid.uuid4().hex[:6]}"
    db.execute_commit("""
    INSERT INTO documents (id, business_id, original_filename, saved_filename, file_type, file_size_bytes, extraction_status, raw_text, page_count)
    VALUES (%s, %s, %s, %s, 'pdf', 1024, 'extracted', %s, 1)
    """, (dummy_doc_id, biz_id, f"invoice_{inv_num}.pdf", f"invoice_{inv_num}.pdf", chunk_text))
    
    rag_engine.chunk_document(dummy_doc_id, biz_id, {
        "original_filename": f"invoice_{inv_num}.pdf",
        "doc_type": "invoice",
        "pages": [{"page_number": 1, "text": chunk_text}]
    })

    return jsonify({
        "success": True,
        "invoice_id": inv_id,
        "invoice_number": inv_num,
        "total_amount": total_amount,
        "balance_due": balance_due,
        "payment_status": payment_status,
        "pdf_url": f"/api/invoices/{inv_id}/pdf"
    })

@app.route('/api/chat', methods=['POST'])
def api_chat():
    """Ask VyaparAI interactive Q&A endpoint with thinking steps."""
    biz = db.get_active_business()
    data = request.json or {}
    question = (data.get("question") or data.get("message") or "").strip()
    language = data.get("language", "en")

    if not question:
        return jsonify({"success": False, "error": "Question cannot be empty."}), 400

    response = ai_copilot.ask_copilot(biz["id"], question, language=language)
    return jsonify({
        "success": True,
        "question": question,
        "answer": response["answer"],
        "thinking": response.get("thinking", ""),
        "citations": response["citations"],
        "verified_metrics": response["verified_metrics"],
        "language": language
    })

@app.route('/api/rag/trace', methods=['GET', 'POST'])
def api_rag_trace():
    """Live RAG & Agent Inspector endpoint explaining exactly what RAG and Agent are doing."""
    biz = db.get_active_business()
    if request.method == 'POST':
        data = request.json or {}
        query = (data.get("query") or data.get("question") or "Which payments are overdue and what should I do this week?").strip()
    else:
        query = request.args.get("query", "Which payments are overdue and what should I do this week?").strip()

    # Total chunks in database for this business
    total_chunks_row = db.execute_one("SELECT COUNT(*) as count FROM document_chunks WHERE business_id = %s", (biz["id"],))
    total_chunks = total_chunks_row["count"] if total_chunks_row else 0

    # Total documents
    docs = db.execute_query("SELECT id, original_filename, file_type, page_count FROM documents WHERE business_id = %s", (biz["id"],))
    
    # RAG Retrieval
    retrieved = rag_engine.retrieve_relevant_chunks(biz["id"], query, top_k=5)

    # SQL Arithmetic
    metrics = financial_engine.get_dashboard_metrics(biz["id"])
    overdue = financial_engine.get_overdue_invoices(biz["id"])

    # Full Copilot execution with thinking
    copilot_res = ai_copilot.ask_copilot(biz["id"], query, language='en')

    # Agent Pipeline Steps
    top_score = max([c["relevance_score"] for c in retrieved]) if retrieved else 0.0
    pipeline = [
        {
            "step": 1,
            "name": "User Query & Intent Analysis",
            "icon": "📥",
            "status": "completed",
            "detail": f"Received query: '{query}'. Intent classified as: Trade Receivables & MSME Action Plan."
        },
        {
            "step": 2,
            "name": "Deterministic SQL Ground Truth",
            "icon": "🧮",
            "status": "completed",
            "detail": f"Queried database for business '{biz['name']}'. Verified: Total Invoiced = ₹{metrics['total_invoiced']:,.2f}, Received = ₹{metrics['total_received']:,.2f}, Outstanding = ₹{metrics['total_outstanding']:,.2f}, Critical Overdue = ₹{metrics['total_overdue']:,.2f} ({len(overdue)} invoices). Zero LLM hallucinations."
        },
        {
            "step": 3,
            "name": "RAG Vector Semantic Retrieval",
            "icon": "🔍",
            "status": "completed",
            "detail": f"Scanned {total_chunks} vector chunks across {len(docs)} documents. Retrieved top {len(retrieved)} relevant chunks using cosine similarity + keyword matching. Highest match score: {top_score*100:.1f}%."
        },
        {
            "step": 4,
            "name": "Gemini Thinking & Strategic Decision",
            "icon": "🧠",
            "status": "completed",
            "detail": f"Executed Google Gemini 3.8 Flash with MSMED Act 2006 (Section 43B(h)) reasoning framework. Formulated step-by-step thinking traces and prioritized collection ladder."
        },
        {
            "step": 5,
            "name": "Grounded Response & Source Citations",
            "icon": "📝",
            "status": "completed",
            "detail": f"Generated final advisory strictly supported by verified SQL metrics and {len(copilot_res['citations'])} source document citations."
        }
    ]

    return jsonify({
        "success": True,
        "query": query,
        "business_name": biz["name"],
        "total_documents": len(docs),
        "total_indexed_chunks": total_chunks,
        "documents": docs,
        "retrieved_chunks": retrieved,
        "metrics": metrics,
        "pipeline": pipeline,
        "thinking": copilot_res.get("thinking", ""),
        "answer": copilot_res.get("answer", ""),
        "citations": copilot_res.get("citations", [])
    })


@app.route('/api/mode/toggle', methods=['POST'])
def api_toggle_mode():
    """Switches between Demo Mode and Live Business Mode."""
    data = request.json or {}
    new_mode = data.get("mode", "demo")
    active_mode = db.set_current_mode(new_mode)
    if active_mode == "demo":
        from demo_data.seed_demo_data import generate_demo_files, load_demo_records_into_db
        generate_demo_files()
        load_demo_records_into_db()
    biz = db.get_active_business()
    return jsonify({
        "success": True,
        "mode": active_mode,
        "business_name": biz["name"],
        "message": f"Switched to {'Demo Mode (Sample Data)' if active_mode == 'demo' else 'Live Business Mode (Your Real Data)'}."
    })

@app.route('/api/mode/status', methods=['GET'])
def api_mode_status():
    """Returns current active mode."""
    mode = db.get_current_mode()
    biz = db.get_active_business()
    return jsonify({
        "mode": mode,
        "business_name": biz["name"]
    })

@app.route('/api/reminders/generate', methods=['POST'])
def api_generate_reminder():
    """Generates polite, firm, or formal payment reminders in English or Hindi."""
    data = request.json or {}
    invoice_id = data.get("invoice_id")
    tone = data.get("tone", "polite") # polite, firm, formal, urgent
    lang = data.get("language", "en")

    biz = db.get_active_business()
    inv = db.execute_one("SELECT * FROM invoices WHERE id = %s", (invoice_id,))
    if not inv:
        return jsonify({"success": False, "error": "Invoice not found."}), 404

    # Tone logic
    party = inv["party_name"]
    inv_no = inv["invoice_number"]
    bal = float(inv["balance_due"])
    due_d = inv["due_date"]
    biz_name = biz["name"]

    if lang == 'hi':
        if tone == 'urgent':
            text = f"प्रिय {party},\n\nअति आवश्यक सूचना: चालान संख्या #{inv_no} (राशि: ₹{bal:,.2f}) की नियत तिथि {due_d} बीत चुकी है। MSMED अधिनियम व क्रेडिट नीति के अनुसार कृपया इस राशि का तत्काल भुगतान करें।\n\nबैंक/UPI विवरण: 384729104829 (SBI) / UPI: sharmaelectricals@sbi\nसादर,\n{biz_name}"
        elif tone == 'firm':
            text = f"नमस्ते {party},\n\nआपके चालान #{inv_no} का बकाया ₹{bal:,.2f} नियत तिथि ({due_d}) तक प्राप्त नहीं हुआ है। कृपया इस सप्ताह तक खाते का मिलान कर भुगतान सुनिश्चित करें।\n\nधन्यवाद,\n{biz_name}"
        else:
            text = f"नमस्ते {party},\n\nआशा है व्यापार अच्छा चल रहा है। यह एक सौम्य स्मरण पत्र है कि चालान #{inv_no} (राशि: ₹{bal:,.2f}) का भुगतान {due_d} को देय था। कृपया जांच कर भुगतान करें।\n\nसादर,\n{biz_name}"
    elif lang == 'bn':
        if tone == 'urgent':
            text = f"প্রিয় {party},\n\nজরুরী নোটিশ: চালান #{inv_no}-এর বকেয়া ₹{bal:,.2f} (নির্দিষ্ট তারিখ: {due_d}) অবিলম্বে পরিশোধ করুন। পরবর্তী সরবরাহ সচল রাখতে অনুগ্রহ করে আজই পেমেন্ট করুন।\n\nধন্যবাদ,\n{biz_name}"
        else:
            text = f"নমস্কার {party},\n\nচালান #{inv_no}-এর বকেয়া ₹{bal:,.2f} প্রদানের তারিখ {due_d} উত্তীর্ণ হয়েছে। অনুগ্রহ করে এই সপ্তাহের মধ্যে অর্থ পরিশোধের ব্যবস্থা করুন।\n\nसादर,\n{biz_name}"
    elif lang == 'mr':
        if tone == 'urgent':
            text = f"प्रिय {party},\n\nतातडीची सूचना: चलन #{inv_no} ची शिल्लक रक्कम ₹{bal:,.2f} (देय तारीख: {due_d}) अद्याप थकीत आहे. पुढील पुरवठा सुरू ठेवण्यासाठी कृपया तातडीने पेमेंट करा.\n\nधन्यवाद,\n{biz_name}"
        else:
            text = f"नमस्ते {party},\n\nहे एक स्मरणपत्र आहे की चलन #{inv_no} ची रक्कम ₹{bal:,.2f} {due_d} रोजी देय होती. कृपया खात्याची पडताळणी करून पेमेंट लवकरात लवकर पूर्ण करावे.\n\nसादर,\n{biz_name}"
    elif lang == 'ta':
        if tone == 'urgent':
            text = f"அன்புள்ள {party},\n\nஅவசர அறிவிப்பு: விலைப்பட்டியல் #{inv_no} நிலுவைத் தொகை ₹{bal:,.2f} (கெடு தேதி: {due_d}) உடனடியாக செலுத்தப்பட வேண்டும். விநியோக தடையைத் தவிர்க்க இன்றே பணம் செலுத்தவும்.\n\nநன்றி,\n{biz_name}"
        else:
            text = f"வணக்கம் {party},\n\nவிலைப்பட்டியல் #{inv_no} தொகை ₹{bal:,.2f} {due_d} அன்று செலுத்த வேண்டியிருந்தது. தயவுசெய்து இந்த வாரத்திற்குள் நிலுவைத் தொகையை செலுத்தவும்.\n\nநன்றி,\n{biz_name}"
    elif lang == 'te':
        if tone == 'urgent':
            text = f"ప్రియమైన {party},\n\nఅత్యవసర నోటీసు: ఇన్వాయిస్ #{inv_no} బకాయి మొత్తం ₹{bal:,.2f} (గడువు: {due_d}) వెంటనే చెల్లించవలసిందిగా కోరుచున్నాము. మెటీరియల్ సప్లై కొనసాగడానికి దయచేసి వెంటనే పరిష్కరించండి.\n\nభవదీయుడు,\n{biz_name}"
        else:
            text = f"నమస్కారం {party},\n\nఇన్వాయిస్ #{inv_no} మొత్తం ₹{bal:,.2f} గడువు తేదీ {due_d} ముగిసింది. దయచేసి ఈ వారంలోగా బకాయి చెల్లించవలసిందిగా మనవి.\n\nధన్యవాదాలు,\n{biz_name}"
    elif lang == 'gu':
        if tone == 'urgent':
            text = f"પ્રિય {party},\n\nઅતિ મહત્વપૂર્ણ નોટિસ: ઇનવોઇસ #{inv_no} ની બાકી રકમ ₹{bal:,.2f} (મુદત: {due_d}) તાત્કાલિક ચૂકવવા વિનંતી. સપ્લાય ચાલુ રાખવા માટે કૃપા કરીને આજે જ ચુકવણી કરો.\n\nઆભાર,\n{biz_name}"
        else:
            text = f"નમસ્તે {party},\n\nઇનવોઇસ #{inv_no} ની રકમ ₹{bal:,.2f} {due_d} ના રોજ ચૂકવવાની હતી. કૃપા કરીને આ અઠવાડિયામાં હિસાબ ચૂકતે કરવા વિનંતી.\n\nઆભાર,\n{biz_name}"
    elif lang == 'kn':
        if tone == 'urgent':
            text = f"ಆತ್ಮೀಯ {party},\n\nತುರ್ತು ಸೂಚನೆ: ಇನ್ವಾಯ್ಸ್ #{inv_no} ಬಾಕಿ ಮೊತ್ತ ₹{bal:,.2f} (ಗಡುವು ದಿನಾಂಕ: {due_d}) ತಕ್ಷಣವೇ ಪಾವತಿಸಬೇಕಾಗಿದೆ. ಸರಬರಾಜು ಮುಂದುವರಿಸಲು ದಯವಿಟ್ಟು ಇಂದೇ ಪಾವತಿಸಿ.\n\nಧನ್ಯವಾದಗಳು,\n{biz_name}"
        else:
            text = f"ನಮಸ್ಕಾರ {party},\n\nಇನ್ವಾಯ್ಸ್ #{inv_no} ಮೊತ್ತ ₹{bal:,.2f} ಪಾವತಿಸುವ ದಿನಾಂಕ {due_d} ಮೀರಿದೆ. ದಯವಿಟ್ಟು ಈ ವಾರದಲ್ಲಿ ಪಾವತಿಯನ್ನು ಇತ್ಯರ್ಥಗೊಳಿಸಿ.\n\nಧನ್ಯವಾದಗಳೊಂದಿಗೆ,\n{biz_name}"
    else: # en
        if tone == 'urgent':
            text = (
                f"Dear {party},\n\n"
                f"URGENT NOTICE: Invoice #{inv_no} for ₹{bal:,.2f} is significantly overdue (Due Date: {due_d}).\n"
                f"Under MSMED Act Section 43B(h) statutory terms, please arrange immediate remittance today to prevent dispatch holds.\n\n"
                f"Bank/UPI Details: State Bank of India | A/C: 384729104829 | IFSC: SBIN0001234 | UPI: sharmaelectricals@sbi\n"
                f"Regards,\nAccounts Desk\n{biz_name}"
            )
        elif tone == 'firm':
            text = (
                f"Dear {party},\n\n"
                f"This is a formal reminder regarding Invoice #{inv_no} of ₹{bal:,.2f}, which fell due on {due_d}.\n"
                f"We request you to expedite the outstanding settlement by the end of this week.\n\n"
                f"Sincerely,\n{biz_name}"
            )
        else: # polite
            text = (
                f"Dear {party},\n\n"
                f"Hope this message finds you well. This is a gentle reminder that Invoice #{inv_no} (amount: ₹{bal:,.2f}) was due on {due_d}.\n"
                f"If you have already processed this transaction, please accept our thanks and disregard this note.\n\n"
                f"Best regards,\n{biz_name}"
            )

    reminder_id = f"rem_{uuid.uuid4().hex[:8]}"
    db.execute_commit("""
    INSERT INTO payment_reminders (id, business_id, invoice_id, recipient_name, channel, tone, language, reminder_text, status)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'drafted')
    """, (reminder_id, biz["id"], inv["id"], party, "whatsapp", tone, lang, text))

    # Also build WhatsApp link
    party_rec = db.execute_one("SELECT phone, email FROM parties WHERE id = %s", (inv.get("party_id"),))
    phone = party_rec.get("phone") if party_rec else None
    email = party_rec.get("email") if party_rec else None
    wa_info = integrations.generate_whatsapp_link(phone, text)

    return jsonify({
        "success": True,
        "reminder_id": reminder_id,
        "recipient_name": party,
        "invoice_number": inv_no,
        "balance_due": bal,
        "reminder_text": text,
        "whatsapp_url": wa_info["url"],
        "email": email,
        "phone": phone
    })

@app.route('/api/reminders/send_email', methods=['POST'])
def api_send_reminder_email():
    """Sends payment reminder via SMTP or logs simulation mode."""
    data = request.json or {}
    email = data.get("email")
    subject = data.get("subject", "Payment Reminder Notice")
    body = data.get("body", "")

    if not email:
        return jsonify({"success": False, "error": "Email address is required."}), 400

    res = integrations.send_payment_reminder_email(email, subject, body)
    return jsonify(res)

@app.route('/api/action_plan/pdf')
def api_download_action_plan_pdf():
    """Generates and downloads Executive Action Plan PDF."""
    biz = db.get_active_business()
    metrics = financial_engine.get_dashboard_metrics(biz["id"])
    recommendations = ai_copilot.generate_action_plan(biz["id"])
    
    plan_data = {
        "business_name": biz["name"],
        "reference_date": metrics["reference_date"],
        "metrics": metrics,
        "recommendations": recommendations
    }
    pdf_path = Config.GENERATED_FOLDER / "Executive_Action_Plan.pdf"
    pdf_generator.generate_action_plan_pdf(plan_data, pdf_path)
    return send_file(str(pdf_path), as_attachment=True, download_name="VyaparAI_Executive_Action_Plan.pdf")

@app.route('/api/invoices/<inv_id>/pdf')
def api_download_invoice_pdf(inv_id):
    """Downloads standard Tax Invoice PDF."""
    inv = db.execute_one("SELECT * FROM invoices WHERE id = %s", (inv_id,))
    if not inv:
        return "Invoice not found", 404
    items = db.execute_query("SELECT * FROM invoice_items WHERE invoice_id = %s", (inv_id,))
    if not items:
        items = [{"description": "General Trade Items", "quantity": 1, "unit_price": inv["subtotal"], "tax_rate": 18, "total_amount": inv["total_amount"]}]
    
    pdf_path = Config.GENERATED_FOLDER / f"Invoice_{inv['invoice_number']}.pdf"
    pdf_generator.generate_invoice_pdf(inv, items, pdf_path)
    return send_file(str(pdf_path), as_attachment=True, download_name=f"Invoice_{inv['invoice_number']}.pdf")

@app.route('/api/demo/load', methods=['POST'])
def api_load_demo_data():
    """One-click Synthetic Demo Data loader for live demonstration."""
    from demo_data.seed_demo_data import generate_demo_files, load_demo_records_into_db
    generate_demo_files()
    load_demo_records_into_db()
    return jsonify({"success": True, "message": "Synthetic demo invoices, customers, and documents loaded successfully!"})

@app.route('/api/integrations/test_smtp', methods=['POST'])
def api_test_smtp():
    """Tests SMTP connection status."""
    res = integrations.test_smtp_connection()
    return jsonify(res)

if __name__ == '__main__':
    print("=" * 65)
    print(" VyaparAI - AI Copilot for Indian MSMEs")
    print(" AVINYA 2K26 - SIIC, IIT Kanpur")
    print(f" Web Server running at: http://localhost:{Config.PORT}")
    print("=" * 65)
    app.run(host='0.0.0.0', port=Config.PORT, debug=Config.DEBUG)

@app.after_request
def add_header(r):
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    return r
