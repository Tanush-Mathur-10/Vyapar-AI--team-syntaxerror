import os
import sys
import csv
import uuid
import datetime
from pathlib import Path

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Config
from core.pdf_generator import pdf_generator
from core.db import db
from core.rag_engine import rag_engine

DEMO_DIR = Config.DEMO_DATA_FOLDER

SAMPLE_CSV_CONTENT = """invoice_number,customer_name,invoice_date,due_date,subtotal,tax_amount,total_amount,amount_paid,balance_due,payment_status,phone,email
INV-2026-081,Kanpur Heavy Fabricators,2026-08-10,2026-09-10,120000.00,21600.00,141600.00,50000.00,91600.00,overdue,9876543210,accounts@kanpurfabricators.in
INV-2026-088,Ganga Roadways Logistics,2026-08-25,2026-09-25,45000.00,8100.00,53100.00,0.00,53100.00,overdue,9898989898,billing@gangaroadways.com
INV-2026-092,Awadh Hardware & Tools,2026-09-01,2026-10-01,75000.00,13500.00,88500.00,88500.00,0.00,paid,9123456780,awadh.hardware@gmail.com
INV-2026-097,Lucknow Precision Works,2026-09-15,2026-10-05,95000.00,17100.00,112100.00,40000.00,72100.00,overdue,9811223344,info@lucknowprecision.in
INV-2026-105,Varanasi Solar Installations,2026-10-01,2026-11-01,60000.00,10800.00,70800.00,0.00,70800.00,unpaid,9765432100,varanasi.solar@tech.in
INV-2026-110,Prayagraj Electrical Contractors,2026-10-05,2026-11-05,32000.00,5760.00,37760.00,10000.00,27760.00,partially_paid,9450011223,contact@prayagrajelec.in
"""

def generate_demo_files():
    """Creates synthetic demo CSV and PDF invoices."""
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    
    # 1. Write sample CSV
    csv_path = DEMO_DIR / "sample_invoices.csv"
    with open(csv_path, "w", encoding="utf-8") as f:
        f.write(SAMPLE_CSV_CONTENT.strip())
    print(f"Created demo CSV: {csv_path}")

    # 2. Generate PDF Invoices
    sample_pdfs = [
        {
            "filename": "sample_invoice_INV101.pdf",
            "invoice_number": "INV-2026-081",
            "party_name": "Kanpur Heavy Fabricators",
            "customer_gstin": "09ABCDE1234F1Z5",
            "invoice_date": "2026-08-10",
            "due_date": "2026-09-10",
            "subtotal": 120000.00,
            "tax_amount": 21600.00,
            "total_amount": 141600.00,
            "amount_paid": 50000.00,
            "balance_due": 91600.00,
            "payment_status": "overdue",
            "items": [
                {"description": "Industrial Transformer Bushings 33kV", "quantity": 10, "unit_price": 8000.00, "tax_rate": 18.0, "total_amount": 94400.00},
                {"description": "Copper Busbars 50x10mm (6m length)", "quantity": 8, "unit_price": 5000.00, "tax_rate": 18.0, "total_amount": 47200.00}
            ]
        },
        {
            "filename": "sample_invoice_INV102.pdf",
            "invoice_number": "INV-2026-088",
            "party_name": "Ganga Roadways Logistics",
            "customer_gstin": "09XYZAB5678C1Z2",
            "invoice_date": "2026-08-25",
            "due_date": "2026-09-25",
            "subtotal": 45000.00,
            "tax_amount": 8100.00,
            "total_amount": 53100.00,
            "amount_paid": 0.00,
            "balance_due": 53100.00,
            "payment_status": "overdue",
            "items": [
                {"description": "Heavy Duty Distribution Board IP65", "quantity": 3, "unit_price": 15000.00, "tax_rate": 18.0, "total_amount": 53100.00}
            ]
        },
        {
            "filename": "sample_invoice_INV103.pdf",
            "invoice_number": "INV-2026-092",
            "party_name": "Awadh Hardware & Tools",
            "customer_gstin": "09PQRST9012K1Z9",
            "invoice_date": "2026-09-01",
            "due_date": "2026-10-01",
            "subtotal": 75000.00,
            "tax_amount": 13500.00,
            "total_amount": 88500.00,
            "amount_paid": 88500.00,
            "balance_due": 0.00,
            "payment_status": "paid",
            "items": [
                {"description": "Armoured Power Cable 4-Core 16 sq mm", "quantity": 150, "unit_price": 500.00, "tax_rate": 18.0, "total_amount": 88500.00}
            ]
        },
        {
            "filename": "sample_invoice_INV104_overdue.pdf",
            "invoice_number": "INV-2026-097",
            "party_name": "Lucknow Precision Works",
            "customer_gstin": "09LMNOP3456D1Z1",
            "invoice_date": "2026-09-15",
            "due_date": "2026-10-05",
            "subtotal": 95000.00,
            "tax_amount": 17100.00,
            "total_amount": 112100.00,
            "amount_paid": 40000.00,
            "balance_due": 72100.00,
            "payment_status": "overdue",
            "items": [
                {"description": "Schneider Electric MCB 63A 4-Pole", "quantity": 25, "unit_price": 2200.00, "tax_rate": 18.0, "total_amount": 64900.00},
                {"description": "Industrial Surge Protection Devices Class C", "quantity": 10, "unit_price": 4000.00, "tax_rate": 18.0, "total_amount": 47200.00}
            ]
        }
    ]

    for p in sample_pdfs:
        out_file = DEMO_DIR / p["filename"]
        pdf_generator.generate_invoice_pdf(p, p["items"], out_file)
        print(f"Generated demo PDF: {out_file}")

def load_demo_records_into_db():
    """Seeds synthetic demo data directly into MySQL / SQLite database."""
    biz = db.get_active_business()
    biz_id = biz["id"]

    # 1. Ensure Parties (Customers) exist
    parties = [
        {"name": "Kanpur Heavy Fabricators", "phone": "9876543210", "email": "accounts@kanpurfabricators.in", "gstin": "09ABCDE1234F1Z5", "city": "Kanpur"},
        {"name": "Ganga Roadways Logistics", "phone": "9898989898", "email": "billing@gangaroadways.com", "gstin": "09XYZAB5678C1Z2", "city": "Kanpur"},
        {"name": "Awadh Hardware & Tools", "phone": "9123456780", "email": "awadh.hardware@gmail.com", "gstin": "09PQRST9012K1Z9", "city": "Lucknow"},
        {"name": "Lucknow Precision Works", "phone": "9811223344", "email": "info@lucknowprecision.in", "gstin": "09LMNOP3456D1Z1", "city": "Lucknow"},
        {"name": "Varanasi Solar Installations", "phone": "9765432100", "email": "varanasi.solar@tech.in", "gstin": "09QWERT7890J1Z3", "city": "Varanasi"},
        {"name": "Prayagraj Electrical Contractors", "phone": "9450011223", "email": "contact@prayagrajelec.in", "gstin": "09ZXCVB4567M1Z7", "city": "Prayagraj"}
    ]

    party_id_map = {}
    for p in parties:
        existing = db.execute_one("SELECT id FROM parties WHERE business_id = %s AND name = %s", (biz_id, p["name"]))
        if existing:
            p_id = existing["id"]
        else:
            p_id = f"pty_{uuid.uuid4().hex[:8]}"
            db.execute_commit("""
            INSERT INTO parties (id, business_id, name, phone, email, gstin, address, party_type)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 'customer')
            """, (p_id, biz_id, p["name"], p["phone"], p["email"], p["gstin"], f"{p['city']}, Uttar Pradesh"))
        party_id_map[p["name"]] = p_id

    # 2. Register Demo Documents & Invoices
    demo_invoices = [
        {
            "doc_name": "sample_invoice_INV101.pdf",
            "invoice_number": "INV-2026-081",
            "party_name": "Kanpur Heavy Fabricators",
            "invoice_date": "2026-08-10",
            "due_date": "2026-09-10",
            "subtotal": 120000.00,
            "tax_amount": 21600.00,
            "total_amount": 141600.00,
            "amount_paid": 50000.00,
            "balance_due": 91600.00,
            "status": "overdue",
            "notes": "Synthetic Demo: Critical Overdue. Partial payment of ₹50,000 received via NEFT."
        },
        {
            "doc_name": "sample_invoice_INV102.pdf",
            "invoice_number": "INV-2026-088",
            "party_name": "Ganga Roadways Logistics",
            "invoice_date": "2026-08-25",
            "due_date": "2026-09-25",
            "subtotal": 45000.00,
            "tax_amount": 8100.00,
            "total_amount": 53100.00,
            "amount_paid": 0.00,
            "balance_due": 53100.00,
            "status": "overdue",
            "notes": "Synthetic Demo: High Overdue. Zero payment received."
        },
        {
            "doc_name": "sample_invoice_INV103.pdf",
            "invoice_number": "INV-2026-092",
            "party_name": "Awadh Hardware & Tools",
            "invoice_date": "2026-09-01",
            "due_date": "2026-10-01",
            "subtotal": 75000.00,
            "tax_amount": 13500.00,
            "total_amount": 88500.00,
            "amount_paid": 88500.00,
            "balance_due": 0.00,
            "status": "paid",
            "notes": "Synthetic Demo: Fully paid on time via UPI."
        },
        {
            "doc_name": "sample_invoice_INV104_overdue.pdf",
            "invoice_number": "INV-2026-097",
            "party_name": "Lucknow Precision Works",
            "invoice_date": "2026-09-15",
            "due_date": "2026-10-05",
            "subtotal": 95000.00,
            "tax_amount": 17100.00,
            "total_amount": 112100.00,
            "amount_paid": 40000.00,
            "balance_due": 72100.00,
            "status": "overdue",
            "notes": "Synthetic Demo: Overdue 10 days. Partial settlement pending."
        },
        {
            "doc_name": "sample_invoices.csv",
            "invoice_number": "INV-2026-105",
            "party_name": "Varanasi Solar Installations",
            "invoice_date": "2026-10-01",
            "due_date": "2026-11-01",
            "subtotal": 60000.00,
            "tax_amount": 10800.00,
            "total_amount": 70800.00,
            "amount_paid": 0.00,
            "balance_due": 70800.00,
            "status": "unpaid",
            "notes": "Synthetic Demo: Fresh invoice within normal payment terms."
        },
        {
            "doc_name": "sample_invoices.csv",
            "invoice_number": "INV-2026-110",
            "party_name": "Prayagraj Electrical Contractors",
            "invoice_date": "2026-10-05",
            "due_date": "2026-11-05",
            "subtotal": 32000.00,
            "tax_amount": 5760.00,
            "total_amount": 37760.00,
            "amount_paid": 10000.00,
            "balance_due": 27760.00,
            "status": "partially_paid",
            "notes": "Synthetic Demo: Advance payment of ₹10,000 received."
        }
    ]

    for inv in demo_invoices:
        # Document record
        doc_rec = db.execute_one("SELECT id FROM documents WHERE business_id = %s AND original_filename = %s", (biz_id, inv["doc_name"]))
        if doc_rec:
            doc_id = doc_rec["id"]
        else:
            doc_id = f"doc_{uuid.uuid4().hex[:8]}"
            db.execute_commit("""
            INSERT INTO documents (id, business_id, original_filename, saved_filename, file_type, file_size_bytes, extraction_status, raw_text, page_count)
            VALUES (%s, %s, %s, %s, %s, %s, 'extracted', %s, 1)
            """, (doc_id, biz_id, inv["doc_name"], inv["doc_name"], "pdf" if inv["doc_name"].endswith(".pdf") else "csv", 10240, f"Tax Invoice {inv['invoice_number']} Billed To: {inv['party_name']} Amount: INR {inv['total_amount']} Balance Due: {inv['balance_due']} Due Date: {inv['due_date']}"))

            # Create RAG chunk for the document
            chunk_text = f"Invoice {inv['invoice_number']} issued to {inv['party_name']}. Total: INR {inv['total_amount']:.2f}, Paid: INR {inv['amount_paid']:.2f}, Balance Due: INR {inv['balance_due']:.2f}. Invoice Date: {inv['invoice_date']}, Due Date: {inv['due_date']}. Status: {inv['status']}."
            rag_engine.chunk_document(doc_id, biz_id, {
                "original_filename": inv["doc_name"],
                "doc_type": "invoice",
                "pages": [{"page_number": 1, "text": chunk_text}]
            })

        # Insert or update invoice
        inv_check = db.execute_one("SELECT id FROM invoices WHERE business_id = %s AND invoice_number = %s", (biz_id, inv["invoice_number"]))
        party_id = party_id_map.get(inv["party_name"])
        if not inv_check:
            inv_id = f"inv_{uuid.uuid4().hex[:8]}"
            db.execute_commit("""
            INSERT INTO invoices (id, business_id, document_id, party_id, party_name, invoice_number, invoice_type, invoice_date, due_date, subtotal, tax_amount, discount_amount, total_amount, amount_paid, balance_due, payment_status, is_uncertain, notes)
            VALUES (%s, %s, %s, %s, %s, %s, 'sale', %s, %s, %s, %s, 0.00, %s, %s, %s, %s, 0, %s)
            """, (
                inv_id, biz_id, doc_id, party_id, inv["party_name"], inv["invoice_number"],
                inv["invoice_date"], inv["due_date"], inv["subtotal"], inv["tax_amount"],
                inv["total_amount"], inv["amount_paid"], inv["balance_due"], inv["status"], inv["notes"]
            ))

    print(f"Loaded {len(demo_invoices)} synthetic demo invoices and parties successfully!")

if __name__ == "__main__":
    generate_demo_files()
    load_demo_records_into_db()
