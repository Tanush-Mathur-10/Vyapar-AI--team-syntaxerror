# 🚀 VyaparAI — AI Copilot for Indian MSMEs
**AVINYA 2K26 | SIIC, IIT Kanpur**  
*Empowering small Indian businesses with evidence-grounded invoice intelligence, overdue tracking, Gemini thinking reasoning, and automated action plans.*

---

## 📌 Table of Contents
1. [Introduction & Purpose](#-introduction--purpose)
2. [Key Capabilities & The Core Question](#-key-capabilities--the-core-question)
3. [System Architecture](#-system-architecture)
4. [Prerequisites](#-prerequisites)
5. [Windows Setup & Installation (Step-by-Step)](#-windows-setup--installation-step-by-step)
6. [Database Setup: MySQL & SQLite Fallback](#-database-setup-mysql--sqlite-fallback)
7. [AI Setup: Gemini Thinking Copilot & Free Tier](#-ai-setup-gemini-thinking-copilot--free-tier)
8. [Dual Operation Modes: Demo Mode vs Live Mode](#-dual-operation-modes-demo-mode-vs-live-mode)
9. [Running the Application](#-running-the-application)
10. [Complete User Journey & App Tour](#-complete-user-journey--app-tour)
11. [Multilingual Support (8 Indian Languages)](#-multilingual-support-8-indian-languages)
12. [Hands-Free Conversational Voice Agent](#-hands-free-conversational-voice-agent)
13. [Enterprise PDF Generation](#-enterprise-pdf-generation)
14. [Tool & API Integrations (WhatsApp & SMTP)](#-tool--api-integrations-whatsapp--smtp)
15. [Running Automated Tests](#-running-automated-tests)
16. [Troubleshooting & FAQ](#-troubleshooting--faq)
17. [Attributions & Disclosure](#-attributions--disclosure)

---

## 📖 Introduction & Purpose
Micro, Small, and Medium Enterprises (MSMEs) form the backbone of the Indian economy. However, small business owners and traders constantly struggle with:
- Delayed payments and working-capital crunches under Section 43B(h) of the Income Tax Act & MSMED Act.
- Complex accounting software that is difficult for non-tech-savvy shop owners.
- Paper bills, messy PDFs, and unorganized ledgers.
- AI chatbots that "hallucinate" fake balances or make up dates.

**VyaparAI** is a production-grade, connected web application built for the **AVINYA 2K26 Hackathon at SIIC, IIT Kanpur**. It connects directly to a unified SQL database to deliver **100% deterministic financial calculations** paired with **genuine Retrieval-Augmented Generation (RAG)**, **Google Gemini step-by-step thinking reasoning**, and **conversational Indian-language voice guidance**.

---

## 🎯 Key Capabilities & The Core Question
The primary question VyaparAI answers with verified mathematical certainty is:

> **"Which payments are overdue and what should I do this week?"**

### Strict Financial Truth Rules:
- **Backend Calculates, AI Explains:** The Python backend computes financial figures using SQL arithmetic; the AI interprets and formats those numbers without inventing or re-calculating them.
- **Partial Payments:** If an invoice of ₹1,00,000 has ₹40,000 paid, the pending balance is precisely ₹60,000.
- **Missing Due Dates:** An invoice with a missing due date is **never** marked overdue.
- **Fully Paid Invoices:** Fully paid invoices are **never** treated as overdue, regardless of invoice date.
- **Citations:** Every AI response points to verified source documents (`[Invoice: sample_invoice_INV101.pdf | Page: 1]`).
- **Thinking Transparency:** Users can expand the "🧠 AI Thinking & Analysis Steps" accordion to inspect the exact reasoning steps used before drawing conclusions.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    User([Business Owner / MSME Trader]) <--> WebUI[VyaparAI Web Dashboard]
    
    subgraph Frontend["Frontend Layer (HTML5 / Modern SaaS CSS / Vanilla JS)"]
        WebUI --> ModeSwitch[Demo / Live Mode Switcher]
        WebUI --> VoiceAgent[Conversational Voice Agent (Web Speech)]
        WebUI --> LangSelector[8 Indian Languages Selector]
        WebUI --> AppGuide[Interactive App Guide & Tour]
        WebUI --> ActionCenter[Action Center Dashboard & Charts]
        WebUI --> ChatCopilot[Ask VyaparAI & Thinking Inspector]
        WebUI --> ReminderGen[Payment Reminder Generator]
        WebUI --> DocReview[Document Upload & Review]
    end

    subgraph Backend["Backend Layer (Python / Flask)"]
        ActionCenter <--> FlaskApp[Flask REST Controllers]
        ChatCopilot <--> FlaskApp
        ReminderGen <--> FlaskApp
        DocReview <--> FlaskApp
        
        FlaskApp --> DocParser[Document Parser (pypdf, pandas, PIL)]
        FlaskApp --> FinEngine[Financial Engine (Overdue & Aging Logic)]
        FlaskApp --> RAGEngine[RAG Engine (Embeddings & Hybrid Search)]
        FlaskApp --> AICopilot[AI Copilot (Gemini Thinking Engine)]
        FlaskApp --> PDFGen[ReportLab CA-Grade PDF Engine]
        FlaskApp --> Integrations[Integrations Manager (SMTP / WhatsApp)]
    end

    subgraph Database["Data & Vector Storage"]
        FinEngine <--> DB[(MySQL 8.0+ / SQLite Engine)]
        RAGEngine <--> DB
        FlaskApp <--> DB
    end

    subgraph External["External AI & Messaging Services"]
        AICopilot -.-> Gemini[Google Gemini 3.8 Flash Thinking API]
        RAGEngine -.-> GemEmbed[text-embedding-004]
        Integrations -.-> WhatsApp[WhatsApp Web / Desktop Deep Link]
        Integrations -.-> SMTP[SMTP Mail Server]
    end
```

---

## 💻 Prerequisites
Make sure your Windows system has the following installed:
1. **Python 3.10 to 3.13** (Verify by running `python --version` in PowerShell).
2. **Git** (Verify by running `git --version`).
3. **Web Browser** (Google Chrome or Microsoft Edge recommended for Voice Assistant features).

---

## ⚙️ Windows Setup & Installation (Step-by-Step)

### Step 1: Open PowerShell
Press `Win + R`, type `powershell`, and hit Enter.

### Step 2: Navigate to Project Directory
```powershell
cd "C:\Users\Tanush Mathur\.gemini\antigravity\scratch\VyaparAI"
```

### Step 3: (Optional) Create & Activate a Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```
*(If PowerShell restricts scripts, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and re-run activate).*

### Step 4: Install Dependencies
Install all required libraries using pip:
```powershell
pip install -r requirements.txt
```
*(Packages installed include `Flask`, `PyMySQL`, `SQLAlchemy`, `pypdf`, `reportlab`, `pandas`, `pillow`, `scikit-learn`, `google-generativeai`).*

---

## 🗄️ Database Setup: MySQL & SQLite Fallback
VyaparAI features an intelligent **Dual-Engine Database Manager**:
1. **SQLite (Zero-Friction Evaluation):** Works instantly out-of-the-box without needing MySQL installed or running!
2. **MySQL 8.0+ (Production Ready):** Uses exact `DECIMAL(12, 2)` monetary columns, foreign keys, and indexed queries.

### Option A: Out-of-the-Box SQLite Mode (Default & Instant)
Your `.env` file is already pre-configured to `DB_TYPE=sqlite`.  
Simply initialize the database:
```powershell
python init_db.py
```
You will see:
```
SUCCESS: Database initialized successfully with SQLITE engine.
Default Business Profile Active: Sharma Electricals & Hardware Enterprises
```

### Option B: MySQL Mode (Full MySQL Server / XAMPP)
If you have MySQL or XAMPP running locally:
1. Open MySQL Command Line or phpMyAdmin and create the database:
   ```sql
   CREATE DATABASE vyaparai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. Edit your `.env` file:
   ```ini
   DB_TYPE=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_NAME=vyaparai_db
   DB_USER=root
   DB_PASSWORD=your_actual_mysql_password
   ```
3. Initialize the MySQL tables:
   ```powershell
   python init_db.py
   ```
*(Note: If MySQL is selected in `.env` but cannot be contacted, VyaparAI automatically falls back to SQLite so the application never crashes!)*

---

## 🧠 AI Setup: Gemini Thinking Copilot & Free Tier
VyaparAI is equipped with Google's advanced **Gemini Thinking Engine**:

### 1. Active Gemini API Key
The application is pre-configured in `.env` with a free-tier Gemini API key and model `models/gemini-3.8-flash`:
```ini
GEMINI_API_KEY=AQ.Ab8RN6KmCDnIMzESGZ5SzA5wi5gYdMreR66Ev81smj0LvnUm-A
GEMINI_MODEL=models/gemini-3.8-flash
```

### 2. Trained on Indian MSME Realities
The Copilot prompt is specifically trained to reason about:
- **MSMED Act 2006 (Section 43B(h)):** Invoices older than 45 days face income tax disallowances for buyers, giving MSMEs statutory leverage.
- **Kanpur Industrial Trade & Wholesale Credit:** Local payment terms, transport bilti receipts, and formal notice escalation ladders.
- **Transparent Thinking Inspection:** Outputs a `<thinking>` thought log shown in a modern accordion before the final grounded answer.

### 3. Resilient Grounded Local Fallback
If the network is unavailable or Google API is undergoing maintenance:
- VyaparAI's local grounded intelligence engine automatically generates step-by-step thinking traces and mathematical action plans with source citations!

---

## 🔄 Dual Operation Modes: Demo Mode vs Live Mode
VyaparAI supports seamless switching between two isolated environments:

| Mode | Badge in Navbar | Purpose | Data Source |
| :--- | :--- | :--- | :--- |
| **🟡 Demo Mode** | `🟡 Demo Mode (Sample Data)` | Hackathon evaluation, training, and exploring features. | Pre-loaded synthetic Kanpur MSME invoices & transactions. |
| **🟢 Live Mode** | `🟢 Live Mode (Real Business)` | Daily real-world business operations. | Fresh, clean database for your real invoices, customers, and GST records. |

### How to Switch:
1. Click the **Demo / Live Mode toggle button** in the top-right of the navigation bar.
2. A confirmation modal appears explaining the mode switch.
3. Click **Confirm Switch**.
4. The page reloads instantly into your chosen workspace!

---

## 🚀 Running the Application

### 1. Launch the Server
From the project folder, run:
```powershell
python app.py
```

You will see:
```
=================================================================
 VyaparAI - AI Copilot for Indian MSMEs
 AVINYA 2K26 - SIIC, IIT Kanpur
 Web Server running at: http://localhost:5000
=================================================================
```

### 2. Open in Your Browser
Navigate to:
👉 **`http://localhost:5000`**

---

## 🧭 Complete User Journey & App Tour

Click **"🧭 App Guide"** in the top navigation bar anytime to open an interactive walkthrough!

### 1. Action Center Dashboard (`/`)
- **Vernacular Subtitles & High-Contrast Cards:** Designed for small shop owners with Hindi & English subtitles:
  - 🟢 **Total Billed / कुल जारी बिल:** Total sales volume.
  - 🔵 **Cash Collected / आया हुआ पैसा:** Cleared bank deposits.
  - 🟡 **Pending Balance / बाकी बचा पैसा:** Outstanding dues.
  - 🔴 **Actionable Overdue / तुरंत वसूली योग्य:** Overdue invoices that require immediate follow-up.
- **Enhanced Charts:** Modern doughnut distribution + 30-day payment aging bucket bar chart.
- **Prioritized Action Cards:** Finding → Verified facts → Supporting documents → Recommended action → Expected impact.

### 2. Ask VyaparAI with Thinking Steps (`/chat`)
- Click **"Ask VyaparAI & Voice"**.
- Try the pre-set prompt: *"Which payments are overdue and what should I do this week?"*
- **Inspect AI Thinking Steps:** Click the **"🧠 AI Thinking & Analysis Steps"** accordion to read how the AI verified due dates, checked payment ledgers, and applied MSMED rules before answering.
- **Inspect Source Citations:** Real document names (`sample_invoice_INV101.pdf`) and page numbers are cited.
- **Voice Readout:** Click **🔊 Listen** to hear the answer spoken aloud.

### 3. Upload & Review Documents (`/documents`)
- Click **"Documents & Review"**.
- Upload PDF invoices or CSV transaction files.
- Click **"🔍 Inspect & RAG Chunks"** to view extracted fields, correct uncertain values, and inspect the semantic text chunks indexed for vector retrieval.

### 4. Create Invoices & Generate CA-Grade PDFs (`/invoices`)
- Click **"Invoices & Bills"** → **"➕ Create New Invoice"**.
- Enter line items, price, and GST percentage.
- Generates an enterprise-styled **Indian Tax Invoice PDF** with navy headers, tax breakup (CGST/SGST/IGST), bank details, UPI QR box, and MSMED Section 43B(h) terms.

### 5. Multi-Tone Payment Reminders (`/reminders`)
- Click **"Payment Reminders"**.
- Choose customer, tone (*Gentle*, *Formal*, *Urgent*), and language (up to 8 Indian languages).
- Click **"✨ Draft Payment Reminder"**.
- Dispatch via **💬 WhatsApp Web** with pre-filled message, **✉️ SMTP Email**, or download a **📥 Printable Demand Notice PDF**.

---

## 🇮🇳 Multilingual Support (8 Indian Languages)
VyaparAI is built for diverse Indian business communities across North, South, East, and West India.

Select your preferred language from the top bar dropdown:
1. **English**
2. **हिन्दी (Hindi)**
3. **বাংলা (Bengali)**
4. **मराठी (Marathi)**
5. **தமிழ் (Tamil)**
6. **తెలుగు (Telugu)**
7. **ગુજરાતી (Gujarati)**
8. **ಕನ್ನಡ (Kannada)**

The UI elements dynamically translate, and payment reminders can be drafted directly in the customer's native mother tongue!

---

## 🎙️ Hands-Free Conversational Voice Agent
Built specifically for non-tech-savvy traders who prefer speaking to an assistant:
1. Click **"🎙️ Talk to Agent"** in the top navigation bar.
2. A full-screen conversational voice modal opens with a pulsing animated AI orb.
3. Speak your question naturally in English or Hindi (e.g., *"How much money is overdue?"*).
4. Speech is transcribed in real-time.
5. When you finish speaking, VyaparAI queries the database, displays the answer, and speaks the recommendation back to you automatically!

---

## 📄 Enterprise PDF Generation
VyaparAI generates three CA-grade, enterprise-styled PDF documents using ReportLab:
1. **Executive Action Plan PDF:** Complete management briefing with KPI summaries, overdue schedules, and verified action steps (accessible via the top bar **📄 Action Plan PDF** button).
2. **Indian Tax Invoice PDF:** CA-compliant layout featuring seller/buyer GSTINs, HSN codes, CGST/SGST breakdown, bank remittance details, and MSMED payment terms.
3. **Formal Demand Notice PDF:** Legal payment reminder letter referencing Section 43B(h) and MSMED Act interest provisions.

---

## 🔌 Tool & API Integrations (WhatsApp & SMTP)
Navigate to **"Integrations"** (`/integrations`):
- **WhatsApp Click-to-Chat Deep Linking:** Generates direct `https://wa.me/` links that launch WhatsApp Web or Mobile without needing expensive third-party SMS APIs.
- **SMTP Email Server:** Configurable live SMTP email dispatch for invoices and reminders, with automatic Simulation Mode fallback when credentials are not supplied.

---

## 🧪 Running Automated Tests
The application includes a comprehensive test suite of 16 unit and integration tests:

Run tests from PowerShell:
```powershell
python -m unittest discover tests
```

Output:
```
Ran 16 tests in 0.664s

OK
```

### What is tested:
- `tests/test_calculations.py`: Overdue calculations, partial payments, missing due dates, fully paid exclusions.
- `tests/test_rag.py`: Semantic chunking, metadata preservation, hybrid retrieval boosting, Hindi query expansion.
- `tests/test_workflow.py`: All 8 web routes, invoice generation, PDF exports, AI chat with thinking, payment reminders, and integrations.

---

## ❓ Troubleshooting & FAQ

### Q1: The server says `Address already in use` on port 5000.
**A:** Another process is using port 5000. Change the port in `.env` to `PORT=5050` and restart `python app.py`.

### Q2: Can I run VyaparAI without an internet connection?
**A:** Yes! VyaparAI includes a deterministic local reasoning engine, local TF-IDF vector matching, and offline PDF generation. All core workflows run 100% locally.

### Q3: What happens if my MySQL server goes down?
**A:** The database engine automatically detects MySQL unavailability, activates SQLite fallback, and keeps running seamlessly without crashes.

### Q4: How do I reset demo data?
**A:** Click **"⚡ Load Demo Data"** anytime to reset synthetic records.

---

## 📜 Attributions & Disclosure
- Built for **AVINYA 2K26**, Startup Incubation and Innovation Centre (SIIC), IIT Kanpur.
- See [`ATTRIBUTIONS.md`](file:///C:/Users/Tanush%20Mathur/.gemini/antigravity/scratch/VyaparAI/ATTRIBUTIONS.md) for full details on third-party libraries, AI models, and synthetic demo datasets.
