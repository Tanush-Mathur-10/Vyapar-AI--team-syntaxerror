# ATTRIBUTIONS.md — External Resources & Disclosures
**Project:** VyaparAI — AI Copilot for Indian MSMEs  
**Event:** AVINYA 2K26, SIIC, IIT Kanpur  

This document provides full transparency on all external dependencies, libraries, AI models, APIs, and datasets utilized in the **VyaparAI** application.

---

## 1. AI Models & Cloud APIs
- **Google Gemini 1.5 Flash (`gemini-1.5-flash`)**:
  - *Provider:* Google AI Studio / DeepMind.
  - *Usage:* Contextual natural language business reasoning, multilingual interpretation (English & Hindi), and grounded recommendation formulation.
  - *Tier:* Free Tier API (`https://aistudio.google.com/app/apikey`).
- **Google Text Embedding Model (`models/text-embedding-004`)**:
  - *Provider:* Google AI Studio.
  - *Usage:* High-dimensional vector representation of business invoice text chunks for semantic retrieval.
- **Local Fallback Engine**:
  - *Description:* Custom offline deterministic rule-grounded reasoning engine and TF-IDF projection vectorizer. Ensures 100% application uptime without API key or network access.

---

## 2. Browser & Native Web APIs
- **Web Speech Recognition API (`SpeechRecognition` / `webkitSpeechRecognition`)**:
  - *Provider:* W3C Standard Browser Web API.
  - *Usage:* Bonus C voice input transcription supporting Indian English (`en-IN`) and Hindi (`hi-IN`).
- **Web Speech Synthesis API (`window.speechSynthesis`)**:
  - *Provider:* W3C Standard Browser Web API.
  - *Usage:* Native text-to-speech engine to read aloud AI financial recommendations in English and Hindi.
- **WhatsApp Click-to-Chat URI Scheme (`https://wa.me`)**:
  - *Provider:* Meta / WhatsApp standard deep-linking.
  - *Usage:* Instant transmission of pre-filled, URI-encoded payment reminder notices directly to client mobile and desktop instances without proprietary API licensing fees.

---

## 3. Open-Source Python Libraries & Licenses
| Library | Version | License | Purpose |
| :--- | :--- | :--- | :--- |
| **Flask** | `>=3.0.0` | BSD-3-Clause | Web framework and RESTful API backend routing |
| **PyMySQL** | `>=1.1.0` | MIT | High-performance MySQL 8.0+ native database driver |
| **SQLAlchemy** | `>=2.0.0` | MIT | SQL schema management and connection abstraction |
| **pypdf** | `>=5.0.0` | BSD-3-Clause | Pure-Python PDF text and page extraction |
| **ReportLab** | `>=4.0.0` | BSD-3-Clause | Programmatic PDF generation for Action Plans, Invoices & Reminders |
| **fpdf2** | `>=2.7.0` | LGPL-3.0 | Fallback PDF formatting utility |
| **Pillow (PIL)** | `>=10.0.0` | HPND | Image parsing, format verification, and OCR preparation |
| **pandas** | `>=2.0.0` | BSD-3-Clause | CSV tabular data parsing and column normalization |
| **scikit-learn** | `>=1.4.0` | BSD-3-Clause | TF-IDF vectorization and cosine similarity calculation |
| **google-generativeai** | `>=0.8.0` | Apache-2.0 | Official Google GenAI SDK |
| **python-dotenv** | `>=1.0.0` | BSD-3-Clause | Secure environment variable configuration |
| **Werkzeug** | `>=3.0.0` | BSD-3-Clause | WSGI utilities and secure filename handling |

---

## 4. Frontend Libraries & Design Assets
- **Chart.js** (`4.4.x` via CDN):
  - *License:* MIT License.
  - *Usage:* Responsive doughnut and bar charts for cash flow analysis, collected vs overdue aging metrics.
- **Inter & System UI Typography**:
  - *License:* SIL Open Font License / Native System Typography.
  - *Usage:* Modern, high-legibility enterprise typography tailored for financial dashboards.

---

## 5. Synthetic Datasets Disclosure
- **Demo Invoices & Parties**:
  - All customer names (*e.g., Kanpur Heavy Fabricators, Ganga Roadways Logistics, Awadh Hardware & Tools, Lucknow Precision Works*), invoice numbers (*e.g., INV-2026-081*), phone numbers, GSTIN identifiers, and financial values are **100% synthetic mock records generated specifically for AVINYA 2K26 demonstration purposes**.
  - No real-world customer or proprietary business data is included.
